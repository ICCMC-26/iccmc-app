# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · اضغط مرتين على هذا الملف
=============================================
هذا هو الملف الوحيد الذي تحتاجه. كل ما عداه في مجلد «ملفات التشغيل» بجانبه —
لا تحذفه ولا تنقله.

A .pyw is run by pythonw.exe, so there is NO console window — just the app.

The catch a .pyw normally has is that a startup crash is completely SILENT: the window simply
never appears and you are left with nothing to report. So everything here is wrapped, and any
failure is shown in a message box instead of vanishing. «ملفات التشغيل/pump.bat» is the console
version for when you want the full traceback.
"""
import pathlib
import sys
import traceback

HERE = pathlib.Path(__file__).resolve().parent
CORE = HERE / "ملفات التشغيل"          # the machinery, kept out of the user's way
sys.path.insert(0, str(CORE))
NL = chr(10)


def _die(title, msg):
    """Never fail silently — a .pyw with no console owes the user an explanation."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk(); r.withdraw()
        messagebox.showerror(title, msg)
        r.destroy()
    except Exception:
        # even the message box failed (no display?) — leave a file so there is still a trace
        try:
            (HERE / "startup-error.txt").write_text(title + NL + NL + msg + NL, encoding="utf-8")
        except Exception:
            pass
    sys.exit(1)


def main():
    if not CORE.is_dir():
        _die("مجلد ملفات التشغيل مفقود",
             "لا بد أن يبقى مجلد «ملفات التشغيل» بجانب هذا الملف." + NL
             + "المتوقع هنا:" + NL + str(CORE))
    if sys.version_info < (3, 8):
        _die("Python قديم",
             "هذه الأداة تحتاج Python 3.8 أو أحدث." + NL + "الموجود: " + sys.version.split()[0])
    try:
        import tkinter as tk
    except Exception as e:
        _die("tkinter غير متوفر",
             "تعذّر تحميل واجهة tkinter — أعِد تثبيت Python مع خيار «tcl/tk»." + NL + NL + str(e))
    try:
        from pump_gui import App, enable_dpi
    except SystemExit as e:                     # Config raises this for a missing pump.ini
        _die("الإعداد ناقص", str(e))
    except Exception:
        _die("تعذّر بدء الأداة", traceback.format_exc())
    try:
        k = enable_dpi()      # MUST run before tk.Tk(), or Windows stretches (= blurry) the window
        root = tk.Tk()
        App(root, k)
        root.mainloop()
    except Exception:
        _die("توقفت الأداة", traceback.format_exc())


if __name__ == "__main__":
    main()
