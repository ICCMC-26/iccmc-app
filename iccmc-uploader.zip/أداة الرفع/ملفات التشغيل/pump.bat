@echo off
REM النسخة التشخيصية — تُظهر الخطأ كاملاً
cd /d "%~dp0"
python pump_gui.py
if errorlevel 1 pause
