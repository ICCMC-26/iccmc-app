# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · the window
===============================
Tkinter on purpose: it ships with Python, so there is nothing to install and no PyInstaller .exe
to be quarantined by antivirus.

Design notes, because the first version was criticised fairly:
  • Colours are the app's OWN brand tokens (read from assets/app.css), not approximations, so the
    tool looks like part of the system rather than a utility bolted on.
  • Everything lives in a CENTRED column with a maximum width. Tk stretches widgets to fill by
    default, which is why maximising the first version looked broken — a full-screen window now
    just gets more margin, exactly as the web app does.
  • Type has a real hierarchy (title / label / data), and numbers are set in a monospace face so
    a changing count does not make the line jitter.
  • ADD FILES is a first-class button. Requiring the user to go to Explorer, copy files in, come
    back and press start is a worse flow than the drop zone it is replacing.
"""
from __future__ import annotations
import pathlib, queue, shutil, sys, threading, time, tkinter as tk
from tkinter import filedialog, ttk

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import dnd
import protocol
from pump import Config, Pump                      # noqa: E402

# the app's own tokens (assets/app.css :root)
BG      = "#1b2930"
PANEL   = "#21403b"
CARD    = "#2c3533"
INK     = "#f7f4ec"
INK2    = "#dcd8cc"
MUTED   = "#a7ada6"
LINE    = "#3c4f4d"
COPPER  = "#dba875"
TEAL    = "#6fc0c0"
RED     = "#ff4d59"
# the intake buckets have their OWN tokens in app.css — the chips borrow brand colours, but a
# bucket is always ok/warn/red. Using teal+copper here made two different things look the same.
OK      = "#63d18a"      # --ok    · committed
WARN    = "#f7b64f"      # --warn  · needs review
LANDED  = "#4bd6a0"      # .ik-row.landed .ik-state

UI   = "Segoe UI"
MONO = "Consolas"
NL   = chr(10)          # newlines are built explicitly rather than escaped
MAXW = 620          # the content column never grows past this; maximising adds margin, not stretch


def enable_dpi():
    """Declare DPI awareness BEFORE Tk starts, or Windows renders the window at 96 DPI and
    bitmap-STRETCHES it to the display's scale. That stretch is what makes the text look blurry
    and the whole thing cheap — this screen runs at 120 DPI (1.25x), so every glyph was being
    resampled. Declared, Tk draws at native resolution and the type is sharp.

    Must run before the first tk.Tk(); called from both entry points. Returns the scale factor so
    pixel geometry can be scaled too — point-sized fonts Tk handles itself."""
    scale = 1.0
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor v2 (Win 8.1+)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()           # fallback (Vista+)
        u = ctypes.windll.user32
        dc = u.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)         # LOGPIXELSX
        u.ReleaseDC(0, dc)
        scale = max(1.0, dpi / 96.0)
    except Exception:
        pass                                                    # not Windows, or no shcore
    return scale


def _btn(parent, text, cmd, *, kind="ghost", font=None, padx=16, pady=8):
    """A flat button with a HOVER state.

    Tk buttons default to a raised 3-D border and no hover feedback, which is most of why the
    window read as dated. Flat + a colour shift on hover is what the web app does, and it is the
    single biggest change in making this feel like the same product.

      filled → the one primary action     ghost → secondary     quiet → tertiary/text
    """
    look = {"filled": dict(bg=COPPER, fg="#1a1206", hbg="#e9bd8f", hfg="#1a1206"),
            "ghost":  dict(bg=BG,     fg=COPPER,    hbg=CARD,      hfg=INK),
            "quiet":  dict(bg=BG,     fg=MUTED,     hbg=BG,        hfg=COPPER)}[kind]
    b = tk.Button(parent, text=text, command=cmd, bd=0, relief="flat",
                  highlightthickness=0, activebackground=look["hbg"],
                  activeforeground=look["hfg"], bg=look["bg"], fg=look["fg"],
                  font=font or (UI, 10), padx=padx, pady=pady, cursor="hand2")
    def on(_):  b.config(bg=look["hbg"], fg=look["hfg"])
    def off(_):
        if str(b["state"]) != "disabled": b.config(bg=look["bg"], fg=look["fg"])
    b.bind("<Enter>", on); b.bind("<Leave>", off)
    b._look = look
    return b


class App:
    def __init__(self, root: tk.Tk, scale: float = 1.0):
        self.root = root
        self.k = scale                       # pixel geometry must follow the display scale
        px = lambda n: int(n * scale)
        self.px = px
        root.title("ICCMC · أداة الرفع")
        root.configure(bg=BG)
        root.geometry(f"{px(720)}x{px(830)}")
        root.minsize(px(560), px(620))

        try:
            self.cfg, self.err = Config(HERE / "pump.ini"), None
        except SystemExit as e:
            self.cfg, self.err = None, str(e)

        self.pump = None
        self.events = queue.Queue()
        self.t0 = None
        # ONE explicit flag for "a run is in progress". This used to be inferred from the progress
        # bar (pump exists AND value < maximum), which silently lied after a failed sign-in: the
        # pump object lingered, stop was never set, and the bar sat at 0/100 because the 'start'
        # event never fired — so Start believed a run was active and did NOTHING when pressed.
        # State that matters is never read back out of a widget.
        self.running = False
        self._style()

        # ── centred column ─────────────────────────────────────────────────
        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True)
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_columnconfigure(1, minsize=0)
        outer.grid_columnconfigure(2, weight=1)
        outer.grid_rowconfigure(0, weight=1)
        col = tk.Frame(outer, bg=BG)
        col.grid(row=0, column=1, sticky="n", pady=26)
        col.grid_columnconfigure(0, minsize=px(MAXW))

        # ── header ─────────────────────────────────────────────────────────
        head = tk.Frame(col, bg=BG); head.grid(row=0, column=0, sticky="ew", padx=4)
        tk.Label(head, text="أداة الرفع", bg=BG, fg=INK,
                 font=(UI, 21, "bold")).pack(anchor="e")
        tk.Label(head, text="ارفع دفعة كبيرة دون المتصفح — الطابور مجلد على قرصك",
                 bg=BG, fg=MUTED, font=(UI, 10)).pack(anchor="e", pady=(2, 0))
        tk.Frame(col, bg=LINE, height=1).grid(row=1, column=0, sticky="ew", pady=(16, 18), padx=4)

        # ── the drop zone · a clone of the web app's .dz ───────────────────
        # Same geometry as assets/app.css: 210px tall, 2px dashed border at 20px radius, a 52px
        # teal icon disc, the same two lines of copy. Tk has no dashed-rounded primitive and no
        # alpha, so the border is drawn as arcs+lines and the disc's rgba(111,192,192,.14) over
        # --card is pre-blended to a flat hex — the eye cannot tell, and it stays one system.
        self.dz = tk.Canvas(col, bg=BG, highlightthickness=0, height=px(186), cursor="hand2")
        self.dz.grid(row=2, column=0, sticky="ew", padx=4)
        self.dz.bind("<Configure>", lambda e: self._paint_dz())
        self.dz.bind("<Button-1>", lambda e: self.add_files())
        self.dz.bind("<Enter>", lambda e: self._paint_dz(hover=True))
        self.dz.bind("<Leave>", lambda e: self._paint_dz(hover=False))
        self._dz_hover = False
        self.ready_var = tk.StringVar(value="")   # live count, refreshed by the folder watcher

        # Nothing else belongs here. The zone opens the file dialog on click, a dragged folder
        # is expanded on drop, and re-sending is handled by the "already pumped — again?" prompt,
        # which clears the old rows first. Buttons for those were three ways to say one thing.
        # ── the list ───────────────────────────────────────────────────────
        # The same shape as the web intake: one row per file, its own state on it, and a مُوجز
        # view that collapses everything already settled so only what needs a human stays. A
        # single bar could say "12 / 30" but never "which twelve" — and not knowing which is
        # exactly what makes a big upload feel like guesswork.
        self.wrap = tk.Frame(col, bg=BG)
        self.wrap.grid(row=3, column=0, sticky="ew", pady=(16, 0), padx=4)

        self.sum_c = tk.Canvas(self.wrap, height=self.px(6), bg=BG, highlightthickness=0)
        self.sum_c.pack(fill="x")
        legend = tk.Frame(self.wrap, bg=BG); legend.pack(fill="x", pady=(8, 0))
        self.legend = legend
        self.view_btn = _btn(legend, "", self.toggle_view, kind="quiet",
                             font=(UI, 9), padx=0, pady=self.px(2))
        self.view_btn.pack(side="left")
        self.legend_box = tk.Frame(legend, bg=BG)
        self.legend_box.pack(side="right")

        holder = tk.Frame(self.wrap, bg=BG); holder.pack(fill="both", expand=True, pady=(10, 0))
        # The list grows with its content up to LIST_MAX and no further; the scrollbar appears
        # only when there is something below the fold. A permanent scrollbar over three rows says
        # "there is more here" when there is not — and in مُوجز, where most rows collapse away,
        # it was claiming that over an empty box.
        self.canvas = tk.Canvas(holder, bg=BG, highlightthickness=0, height=1)
        self.sb = ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.sb.set)
        self.canvas.pack(side="right", fill="both", expand=True)
        self.rows_f = tk.Frame(self.canvas, bg=BG)
        self._win = self.canvas.create_window((0, 0), window=self.rows_f, anchor="nw")
        self.rows_f.bind("<Configure>",
                         lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfig(self._win, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._wheel)

        self.rows = []          # [{name, mb, state, hash, why}] — the run, in order
        self._widgets = {}      # name → (frame, state label) so a row repaints without a rebuild
        self._view = "auto"     # auto | compact | detailed — the count picks, the user overrides
        self.wrap.grid_remove()             # appears only once there is a list to show

        # No global status lines. "you can close the browser", the batch id and a single
        # reading counter all described the BATCH, while the thing being asked about is always a
        # FILE — and the list answers that per row. Each row spins for itself instead.
        self._spinners = []          # live ring canvases; a render rebuilds them
        self._ang = 0
        self._spin_on = False

        self.msg_var = tk.StringVar(
            value=self.err or "")
        self.msg_lbl = tk.Label(col, textvariable=self.msg_var, bg=BG, fg=(RED if self.err else MUTED),
                 wraplength=self.px(MAXW) - 20, justify="right", font=(UI, 9))
        self.msg_lbl.grid(row=5, column=0, sticky="e", pady=(14, 0), padx=4)

        # ── footer ─────────────────────────────────────────────────────────
        foot = tk.Frame(col, bg=BG); foot.grid(row=7, column=0, sticky="ew", pady=(26, 0), padx=4)
        self.go = _btn(foot, "ابدأ الرفع", self.start, kind="filled",
                       font=(UI, 12, "bold"), padx=self.px(32), pady=self.px(12))
        self.go.pack(side="right")
        self.stop_btn = _btn(foot, "إيقاف", self.stop, kind="ghost",
                             font=(UI, 10), padx=self.px(20), pady=self.px(12))
        self.stop_btn.config(state="disabled", fg=LINE)      # visibly inert until a run starts
        self.stop_btn.pack(side="right", padx=(0, self.px(10)))

        if self.err:
            # a tool that cannot reach its config must not offer any door into the queue
            self.go.config(state="disabled")
        else:
            # so the website's "open the uploader" link can reach us (per-user, no admin)
            protocol.register()
            if protocol.launched_by_link():
                self.root.after(300, lambda: self.msg_var.set(
                    "فُتحت من الموقع — أفلِت ملفاتك هنا"))
            self.refresh_ready()
            self.watch_folder()          # the folder IS the queue — notice it changing
            if not dnd.enable(self.root, self.on_drop):
                # never advertise a gesture this machine cannot do
                self.DZ_T = "انقر لاختيار ملفات الموظف"
        self.root.after(120, self.drain)

    # ── styling ─────────────────────────────────────────────────────────────
    def _style(self):
        s = ttk.Style()
        try: s.theme_use("clam")            # the only built-in theme that honours custom colours
        except Exception: pass
        s.configure("I.Horizontal.TProgressbar", troughcolor=CARD, background=COPPER,
                    bordercolor=CARD, lightcolor=COPPER, darkcolor=COPPER,
                    thickness=int(10 * self.k))

    # ── state ───────────────────────────────────────────────────────────────
    def watch_folder(self):
        """Re-count every 1.5s while idle.

        You can put files in two ways — «＋ أضف ملفات», or by copying them into the folder in
        Explorer (which «افتح المجلد» opens for exactly that). The second way left the window
        showing a stale count until you clicked something, which makes the tool look broken when
        it is simply not looking. Cheap: one directory listing, and skipped entirely while a run
        is in progress, since the pump is moving those files itself."""
        try:
            if not self.running:
                self.refresh_ready()
        except Exception:
            pass
        self.root.after(1500, self.watch_folder)

    def refresh_ready(self):
        """How many files are actually sitting in the folder, waiting."""
        if not self.cfg: return 0
        try:
            self.cfg.folder.mkdir(parents=True, exist_ok=True)
            n = sum(1 for p in self.cfg.folder.iterdir()
                    if p.is_file() and not p.name.startswith("."))
        except Exception:
            n = 0
        # the zone above already says how to add; the count only has to say how many
        self.ready_var.set(f"{n} ملف جاهز للرفع" if n else "الطابور فارغ")
        try: self._paint_dz()
        except Exception: pass
        # never re-enable Start mid-run; _idle() owns that when the run ends
        if not self.running:
            self.go.config(state=("normal" if n else "disabled"))
        return n

    # ── the drop zone ───────────────────────────────────────────────────────
    DZ_T = "اسحب ملفات الموظف هنا"
    # split in two ONLY because Tk reverses the segments of a wrapped Arabic line
    DZ_S  = "أو انقر للاختيار · صورة أو PDF أو Excel أو Word"
    DZ_S2 = "ملفات كبيرة مدعومة · عدة ملفات وموظفين معًا"
    DISC = "#354846"      # rgba(111,192,192,.14) over --card, flattened (Tk has no alpha)

    def _paint_dz(self, hover=None):
        """Draw the zone. Called on every resize, so it always fits the column."""
        if hover is not None:
            self._dz_hover = hover
        c = self.dz
        c.delete("all")
        w = c.winfo_width() or self.px(MAXW)
        h = int(c["height"])
        edge = COPPER if self._dz_hover else LINE
        self._rounded_dash(c, 1, 1, w - 2, h - 2, self.px(20), edge)

        cx, top = w // 2, self.px(24)
        r = self.px(26)                                   # .dz-ic is 52px across
        c.create_oval(cx - r, top, cx + r, top + 2 * r, fill=self.DISC, width=0)
        c.create_text(cx, top + r, text="⬆", fill=TEAL, font=(UI, 16, "bold"))
        c.create_text(cx, top + 2 * r + self.px(26), text=self.DZ_T, fill=INK,
                      font=(UI, 13, "bold"))
        c.create_text(cx, top + 2 * r + self.px(48), text=self.DZ_S, fill=MUTED, font=(UI, 9))
        c.create_text(cx, top + 2 * r + self.px(66), text=self.DZ_S2, fill=MUTED, font=(UI, 9))
        # the queue count lives in the zone, because the zone IS the queue
        c.create_text(cx, h - self.px(26), text=self.ready_var.get(), fill=TEAL,
                      font=(UI, 10, "bold"))

    def _rounded_dash(self, c, x0, y0, x1, y1, r, col):
        """A dashed rounded rectangle — Tk has no such primitive, so: 4 arcs + 4 dashed sides."""
        d, wdt = (self.px(6), self.px(4)), 2
        for x, y, start in ((x0, y0, 90), (x1 - 2 * r, y0, 0),
                            (x1 - 2 * r, y1 - 2 * r, 270), (x0, y1 - 2 * r, 180)):
            c.create_arc(x, y, x + 2 * r, y + 2 * r, start=start, extent=90,
                         style="arc", outline=col, width=wdt, dash=d)
        c.create_line(x0 + r, y0, x1 - r, y0, fill=col, width=wdt, dash=d)
        c.create_line(x0 + r, y1, x1 - r, y1, fill=col, width=wdt, dash=d)
        c.create_line(x0, y0 + r, x0, y1 - r, fill=col, width=wdt, dash=d)
        c.create_line(x1, y0 + r, x1, y1 - r, fill=col, width=wdt, dash=d)


    # ── the list ────────────────────────────────────────────────────────────
    # Same words the website uses, so a file means the same thing in both places.
    ST_TXT = {"queued": "بالانتظار", "up": "يُرفع", "sent": "قيد المعالجة",
              "committed": "✓ أُودِعت", "review": "للمراجعة", "refused": "✕ مرفوض",
              "failed": "✕ فشل", "skip": "مُرسَل سابقًا"}
    ST_COL = {"queued": MUTED, "up": MUTED, "sent": MUTED, "committed": LANDED,
              "review": COPPER, "refused": RED, "failed": RED, "skip": MUTED}
    DONE = ("committed", "review", "refused", "failed", "skip")
    NEEDS_ME = ("review", "refused", "failed")
    COMPACT_AT = 20          # a screenful; past this the settled rows collapse by default
    CAP = 200                # never build more widgets than a human can scroll

    def _wheel(self, e):
        try:
            self.canvas.yview_scroll(int(-e.delta / 120), "units")
        except Exception:
            pass

    def toggle_view(self):
        self._view = "detailed" if self._compact() else "compact"
        self.render_list()

    def _compact(self):
        return self._view == "compact" or (self._view == "auto" and len(self.rows) >= self.COMPACT_AT)

    def add_rows(self, names):
        """Seed the list from the folder the moment a run starts — every file visible up front."""
        self.rows = [{"name": n, "mb": mb, "state": "queued", "hash": None, "why": ""}
                     for n, mb in names]
        self._widgets = {}
        self.wrap.grid()
        self.render_list()

    def set_row(self, name, **kw):
        for r in self.rows:
            if r["name"] == name:
                r.update(kw); return r
        return None

    def apply_rows(self, ledger):
        """Fold the server's per-file buckets back onto the list.

        The tool knows a file by name; the ledger knows it by content hash. The upload step
        recorded the hash for exactly this moment — without it the list could only ever show what
        LEAVING looked like, never what ARRIVING looked like.
        """
        by_hash = {r.get("hash"): r for r in self.rows if r.get("hash")}
        for row in ledger or []:
            r = by_hash.get(row.get("image_hash"))
            if not r:
                continue
            b = (row.get("bucket") or "").strip()
            if b == "committed":   r["state"] = "committed"
            elif b == "review":    r["state"] = "review"
            elif b == "refused":
                r["state"] = "refused"
                r["why"] = (row.get("fail_reason") or "").strip()
            r["doc"] = (row.get("doc_type") or "").strip()
        self.render_list()

    def _counts(self):
        c = {k: 0 for k in ("queued", "up", "sent", "committed", "review", "refused",
                            "failed", "skip")}
        for r in self.rows:
            c[r["state"]] = c.get(r["state"], 0) + 1
        return c

    def render_list(self):
        if not self.rows:
            self.wrap.grid_remove(); return
        self.wrap.grid()
        c = self._counts()
        done = c["committed"] + c["skip"]
        busy = c["queued"] + c["up"] + c["sent"]
        compact = self._compact()

        # the summary bar: the whole run in one line, in the same colours as the chips
        self.sum_c.delete("all")
        w = max(self.sum_c.winfo_width(), 1); total = max(len(self.rows), 1)
        x = 0
        for colr, n in ((OK, done), (WARN, c["review"]),
                        (RED, c["refused"] + c["failed"]), (LINE, busy)):
            if not n: continue
            seg = w * n / total
            self.sum_c.create_rectangle(x, 0, x + seg, self.px(6), fill=colr, width=0)
            x += seg

        for ch in self.legend_box.winfo_children():
            ch.destroy()
        # .ik-legend — a dot in the bucket's colour, the count, the word. The dot is what ties a
        # number to its band in the bar above; without it the bar is just a stripe.
        items = [(OK, done, "أُودِعت")]
        if c["review"]:                 items.append((WARN, c["review"], "للمراجعة"))
        if c["refused"] + c["failed"]:  items.append((RED, c["refused"] + c["failed"], "مرفوض"))
        if busy:                        items.append((MUTED, busy, "جارٍ"))
        items.append((None, len(self.rows), "ملف"))
        for i, (colr, n, word) in enumerate(items):
            g = tk.Frame(self.legend_box, bg=BG)
            g.pack(side="right", padx=(0, self.px(16)) if i < len(items) - 1 else 0)
            if colr:
                d = self.px(7)
                dot = tk.Canvas(g, width=d, height=d, bg=BG, highlightthickness=0)
                dot.create_oval(0, 0, d - 1, d - 1, fill=colr, width=0)
                dot.pack(side="right", padx=(self.px(7), 0))
            tk.Label(g, text=word, bg=BG, fg=INK2, font=(UI, 9)).pack(side="right")
            tk.Label(g, text=str(n), bg=BG, fg=INK, font=(MONO, 9, "bold")
                     ).pack(side="right", padx=(self.px(5), 0))
        self.view_btn.config(text=("تفصيلي ›" if compact else "مُوجز ›"))

        # COMPACT shows only what a human must act on; everything settled is already in the bar
        shown = [r for r in self.rows if r["state"] in self.NEEDS_ME] if compact else self.rows
        extra = max(0, len(shown) - self.CAP)
        shown = shown[:self.CAP]

        for ch in self.rows_f.winfo_children():
            ch.destroy()
        if not shown:
            tk.Label(self.rows_f, bg=BG, fg=TEAL, font=(UI, 10, "bold"),
                     text=("أُودِعت كلها ✓" if not busy else "…جارٍ الرفع")
                     ).pack(anchor="e", pady=self.px(18))
        for r in shown:
            self._row_widget(r)
        if extra:
            tk.Label(self.rows_f, text=f"…و {extra} أخرى", bg=BG, fg=MUTED,
                     font=(UI, 9)).pack(anchor="e", pady=(6, 0))
        self.rows_f.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self._fit_list()

    LIST_MAX = 300          # past this the list scrolls instead of pushing the button off-screen

    def _fit_list(self):
        """Size the box to its rows, and show the scrollbar only if they overflow."""
        need = self.rows_f.winfo_reqheight()
        cap  = self.px(self.LIST_MAX)
        self.canvas.configure(height=min(need, cap))
        if need > cap:
            if not self.sb.winfo_manager():
                self.sb.pack(side="left", fill="y", before=self.canvas)
        else:
            self.sb.pack_forget()
            self.canvas.yview_moveto(0)     # nothing hidden above, so never sit scrolled down

    def _row_widget(self, r):
        """One card = one file — the web's .ik-row: state chip, name, size, and for a file still
        going out, the 4px copper sliver that only exists while it is uploading."""
        f = tk.Frame(self.rows_f, bg=CARD)
        f.pack(fill="x", pady=(0, self.px(5)))
        inner = tk.Frame(f, bg=CARD, padx=self.px(13), pady=self.px(9)); inner.pack(fill="x")

        if r["state"] == "review":
            # the web's .ik-review-btn: 1px copper, rgba(197,149,107,.12), radius 9, icon + label
            self._badge(inner, "▤", "الوارد ›").pack(side="left")
        else:
            tk.Label(inner, text=self.ST_TXT.get(r["state"], r["state"]), bg=CARD,
                     fg=self.ST_COL.get(r["state"], MUTED), font=(UI, 9, "bold")).pack(side="left")
            if r["state"] in ("up", "sent"):        # .ik-row.processing .ik-state::before
                self._spinner(inner).pack(side="left", padx=(0, self.px(6)))

        # ✕ removes a file that has NOT gone anywhere yet. Once uploaded the record belongs to the
        # system, and this tool does not delete records — that rule holds here as everywhere.
        if r["state"] == "queued" and not self.running:
            x = tk.Label(inner, text="✕", bg=CARD, fg=MUTED, font=(UI, 10), cursor="hand2")
            x.pack(side="left", padx=(self.px(10), 0))
            x.bind("<Button-1>", lambda e, n=r["name"]: self.drop_file(n))
            x.bind("<Enter>", lambda e, w=x: w.config(fg=INK))
            x.bind("<Leave>", lambda e, w=x: w.config(fg=MUTED))

        txt = tk.Frame(inner, bg=CARD); txt.pack(side="right", fill="x", expand=True)
        tk.Label(txt, text=r["name"], bg=CARD, fg=INK, anchor="e",
                 font=(UI, 10, "bold")).pack(fill="x")
        sub = f"{r['mb']:.1f} MB"
        # no "waiting in الوارد" here — the badge beside it already says exactly that
        if r["state"] == "refused" and r.get("why"):   sub += f" · {r['why'][:60]}"
        elif r["state"] == "failed"  and r.get("why"): sub += f" · {r['why'][:60]}"
        elif r.get("doc"):                             sub += f" · {r['doc']}"
        tk.Label(txt, text=sub, bg=CARD, fg=MUTED, anchor="e", font=(UI, 8)).pack(fill="x")
        if r["state"] == "up":                         # .ik-row.uploading .ik-bar2
            bar = tk.Frame(txt, bg=BG, height=self.px(4)); bar.pack(fill="x", pady=(self.px(6), 0))
            tk.Frame(bar, bg=COPPER, height=self.px(4)).place(relwidth=0.55, relheight=1)

    BADGE_BG = "#41423b"      # rgba(197,149,107,.12) over --card, flattened (Tk has no alpha)

    def _badge(self, parent, icon, text):
        """A rounded, bordered chip — the same object the web puts on a row that needs a human.

        Plain coloured words all read as the same kind of thing; a bordered box reads as somewhere
        to GO. That distinction is the whole point of the state, so it gets the web's shape."""
        f = (UI, 9, "bold")
        probe = tk.Label(parent, text=f"{icon}  {text}", font=f)
        w = probe.winfo_reqwidth() + self.px(26); h = probe.winfo_reqheight() + self.px(12)
        probe.destroy()
        c = tk.Canvas(parent, width=w, height=h, bg=CARD, highlightthickness=0)
        r = self.px(9)
        # rounded rect = 4 arcs + 2 bars, filled then outlined in copper
        for x, y, st in ((0, 0, 90), (w - 2 * r - 1, 0, 0),
                         (w - 2 * r - 1, h - 2 * r - 1, 270), (0, h - 2 * r - 1, 180)):
            c.create_arc(x, y, x + 2 * r, y + 2 * r, start=st, extent=90,
                         style="pieslice", fill=self.BADGE_BG, outline=self.BADGE_BG)
            c.create_arc(x, y, x + 2 * r, y + 2 * r, start=st, extent=90,
                         style="arc", outline=COPPER, width=1)
        c.create_rectangle(r, 0, w - r - 1, h - 1, fill=self.BADGE_BG, width=0)
        c.create_rectangle(0, r, w - 1, h - r - 1, fill=self.BADGE_BG, width=0)
        c.create_line(r, 0, w - r - 1, 0, fill=COPPER)
        c.create_line(r, h - 1, w - r - 1, h - 1, fill=COPPER)
        c.create_line(0, r, 0, h - r - 1, fill=COPPER)
        c.create_line(w - 1, r, w - 1, h - r - 1, fill=COPPER)
        c.create_text(w // 2, h // 2, text=f"{icon}  {text}", fill=COPPER, font=f)
        return c

    def drop_file(self, name):
        """Take a queued file back out of the folder — the queue is a folder, so this is a move."""
        try:
            src = self.cfg.folder / name
            out = self.cfg.folder / "_removed"; out.mkdir(parents=True, exist_ok=True)
            if src.exists():
                shutil.move(str(src), str(out / name))
            self.rows = [r for r in self.rows if r["name"] != name]
            self.refresh_ready(); self.render_list()
            self.msg_var.set(f"أُخرج {name} من الطابور — نُقل إلى _removed")
        except Exception as e:
            self.msg_var.set(f"تعذّر الإخراج: {e}")

    # ── actions ─────────────────────────────────────────────────────────────
    def add_files(self):
        """Pick files from anywhere and copy them into the folder."""
        paths = filedialog.askopenfilenames(
            title="اختر الملفات",
            filetypes=[("كل الملفات المدعومة", "*.pdf *.jpg *.jpeg *.png *.webp *.xlsx *.docx"),
                       ("الكل", "*.*")])
        if paths:
            self._ingest(paths)

    def on_drop(self, paths):
        """Files (or folders) dragged onto the window.

        Dropping is the first thing anyone tries on a tool that replaces a browser drop zone, and
        until now nothing happened — the only ways in were a file dialog or Explorer. A dropped
        FOLDER is expanded, because scans arrive as folders far more often than as loose files."""
        out = []
        for raw in paths:
            q = pathlib.Path(raw)
            if q.is_dir():
                out += [x for x in sorted(q.rglob("*"))
                        if x.is_file() and not x.name.startswith(".")]
            elif q.is_file():
                out.append(q)
        if out:
            self._ingest(out)
        else:
            self.msg_var.set("لا توجد ملفات في ما أُفلِت")

    def _ingest(self, paths):
        """Copy chosen files into the queue folder — the one way in, whatever the door.

        Copying (not moving) is deliberate: the tool must never remove a file from wherever the
        user keeps it. A name already queued is renamed rather than overwritten, because silently
        replacing a file that is waiting to be sent would lose it."""
        if self.running:
            self.msg_var.set("الرفع جارٍ — انتظر انتهاءه ثم أضف")
            return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        added = clash = 0
        for src in paths:
            src = pathlib.Path(src)
            dst = self.cfg.folder / src.name
            if dst.exists():
                stem, suf, i = dst.stem, dst.suffix, 2
                while dst.exists():
                    dst = self.cfg.folder / f"{stem} ({i}){suf}"; i += 1
                clash += 1
            try:
                shutil.copy2(src, dst); added += 1
            except Exception as e:
                self.msg_var.set(f"تعذّر نسخ {src.name}: {e}")
        n = self.refresh_ready()
        self._link(False)
        self.msg_var.set(f"أُضيف {added} ملف — المجموع {n}"
                         + (f" · {clash} بالاسم نفسه أُعيدت تسميتها" if clash else ""))

    def start(self):
        if not self.cfg: return
        if self.running:
            return                                                   # already running
        if not self.refresh_ready():
            self.msg_var.set("الطابور فارغ"); return
        # Asked on the machine, stored in the gitignored pump.ini — the password never travels
        # through a chat, a code edit or a diff. Asked once; later runs read the file.
        if not self.cfg.password:
            from tkinter import simpledialog
            pw = simpledialog.askstring("كلمة المرور",
                                        f"كلمة مرور {self.cfg.email}\n(تُحفظ في pump.ini على جهازك)",
                                        show="•", parent=self.root)
            if not pw:
                self.msg_var.set("لا يمكن الرفع بدون كلمة المرور"); return
            try: self.cfg.save_password(pw.strip())
            except Exception as e:
                self.msg_var.set(f"تعذّر حفظ كلمة المرور: {e}"); return
        if not self._ask_about_known():
            return
        self.pump = Pump(self.cfg, lambda **k: self.events.put(k))
        self.t0 = time.time()
        self.running = True
        self.go.config(state="disabled")
        self.stop_btn.config(state="normal"); self.msg_var.set("")
        # every file on screen BEFORE anything moves — the list is the promise, then the record
        try:
            self.add_rows(sorted((f.name, f.stat().st_size / 1048576)
                                 for f in self.cfg.folder.iterdir()
                                 if f.is_file() and not f.name.startswith(".")))
        except Exception:
            pass
        threading.Thread(target=self._run, daemon=True).start()

    def _ask_about_known(self):
        """Before uploading, say plainly which files the system already has, and let the user choose.

        The uploader used to skip known content silently — so re-adding files looked like nothing
        happened, and the tool felt disconnected from «الوارد». Now it tells you, and «ارفعها
        مجددًا» forgets their rows first, because the line dedups by hash and a re-drop is
        otherwise a no-op. A COMMITTED file is never forgotten — that is an employee record.
        """
        import hashlib
        from tkinter import messagebox
        try:
            files = [f for f in self.cfg.folder.iterdir()
                     if f.is_file() and not f.name.startswith(".")]
            if not files:
                return True
            shas = {}
            for f in files:
                h = hashlib.sha256(); 
                with f.open("rb") as fh:
                    for c in iter(lambda: fh.read(1 << 20), b""): h.update(c)
                shas[f.name] = h.hexdigest()
            api = __import__("pump").Api(self.cfg)
            known = api.known_hashes(list(set(shas.values())))
            if not known:
                return True
            dupes = {n: known[h] for n, h in shas.items() if h in known}
            committed = [n for n, st in dupes.items() if st in ("done", "committed")]
            msg = (f"{len(dupes)} من {len(files)} موجودة في النظام بالفعل")
            if committed:
                msg += NL + f"({len(committed)} منها مُودَعة كموظفين — لن تُحذف)"
            msg += (NL + NL + "نعم = ارفعها مجددًا (سيُعاد قراءتها)"
                    + NL + "لا  = تخطَّها وارفع الجديد فقط"
                    + NL + "إلغاء = لا ترفع شيئًا")
            again = messagebox.askyesnocancel("ملفات مرفوعة مسبقًا", msg, parent=self.root)
            if again is None:
                self.msg_var.set("أُلغي"); return False
            if again:
                forget = [h for n, h in shas.items()
                          if h in known and known[h] not in ("done", "committed")]
                n = api.forget(list(set(forget)))
                self.msg_var.set(f"سيُعاد رفع {n} ملف")
            else:
                self.msg_var.set(f"سيُتخطّى {len(dupes)} ملف مرفوع مسبقًا")
            return True
        except Exception as e:
            self.msg_var.set(f"تعذّر فحص المكرّر: {e}")
            return True                      # never block the upload over a pre-flight check

    def _link(self, on):
        on = bool(on and getattr(self.cfg, "app_url", ""))
        """Turn the result line into a link when there IS somewhere to go.

        A run that ends with files waiting for review should hand the user straight to them —
        the whole point of tying the uploader to «الوارد» is that finishing here means starting
        there. When nothing needs attention the line stays plain text, because a link that leads
        nowhere is worse than no link."""
        if on:
            self.msg_lbl.config(fg=COPPER, cursor="hand2")
            self.msg_lbl.bind("<Button-1>", lambda _e: self._open_inbox())
        else:
            self.msg_lbl.config(fg=MUTED, cursor="")
            self.msg_lbl.unbind("<Button-1>")

    def _open_inbox(self):
        import webbrowser
        if getattr(self.cfg, "app_url", ""):
            webbrowser.open(self.cfg.app_url)

    def _run(self):
        from pump import AuthError
        try:
            self.pump.run()
        except AuthError as e:
            self.cfg.clear_password()      # never keep a credential the server refused
            self.events.put({"kind": "auth", "why": str(e)})
        except Exception as e:
            self.events.put({"kind": "error", "why": f"{type(e).__name__}: {e}"})

    def stop(self):
        if self.pump:
            self.pump.stop.set()
            self.msg_var.set("جارٍ الإيقاف… الملفات قيد الرفع تعود إلى المجلد")

    RING = "#6d5747"        # rgba(197,149,107,.3) over --card, flattened

    def _spinner(self, parent):
        """The web's 11px ring, rotating. Tk cannot animate a border, so it is an arc redrawn on
        a timer — one timer for every ring on screen, stopping the moment none are left."""
        d = self.px(12)
        c = tk.Canvas(parent, width=d, height=d, bg=CARD, highlightthickness=0)
        self._spinners.append(c)
        if not self._spin_on:
            self._spin_on = True
            self.root.after(70, self._tick_spin)
        return c

    def _tick_spin(self):
        self._ang = (self._ang - 30) % 360
        alive = []
        for c in self._spinners:
            try:
                if not int(c.winfo_exists()):
                    continue
                d = int(c["width"]); c.delete("all")
                c.create_oval(2, 2, d - 2, d - 2, outline=self.RING, width=2)
                c.create_arc(2, 2, d - 2, d - 2, start=self._ang, extent=100,
                             style="arc", outline=COPPER, width=2)
                alive.append(c)
            except Exception:
                pass                       # a canvas destroyed mid-render is simply dropped
        self._spinners = alive
        if alive:
            self.root.after(70, self._tick_spin)
        else:
            self._spin_on = False

    def _idle(self):
        """Back to the resting state, ready for the NEXT batch.

        The finished run's list STAYS — it is the receipt, and the whole point of showing which
        file went where. What goes is anything that implies work is still happening: the spinner,
        the "you can close the browser" note, the disabled buttons."""
        self.running = False
        self.go.config(state="normal")
        self.stop_btn.config(state="disabled", fg=LINE)
        self.refresh_ready()
        self.render_list()

    # ── the event pump (worker threads never touch Tk) ──────────────────────
    def drain(self):
        try:
            while True:
                e = self.events.get_nowait(); k = e.get("kind")
                if k == "start":
                    self.msg_var.set("")
                elif k == "begin":
                    self.set_row(e["name"], state="up"); self.render_list()
                elif k in ("ok", "skip", "fail"):
                    self.set_row(e["name"],
                                 state={"ok": "sent", "skip": "skip", "fail": "failed"}[k],
                                 hash=e.get("hash"), why=e.get("why", ""))
                    self.render_list()
                elif k == "reading":
                    # its only job now: give each row its real outcome. The rings say "still
                    # working" far better than a counter that spoke for the whole batch.
                    self.apply_rows(e.get("rows"))
                elif k == "empty":
                    self._link(False)
                    self.msg_var.set("الطابور فارغ"); self._idle()
                elif k == "finish":
                    self._idle()
                    st = e.get("state")
                    if st:
                        # The legend above already states the breakdown, and it stays on screen.
                        # Repeating it as a sentence here said the same thing twice — and Tk's
                        # lack of bidi mangled the guillemets every time.
                        self.msg_var.set("تم الرفع ✓")
                        if st.get("review") or st.get("refused"):
                            self._link(True)
                    else:
                        self.msg_var.set("توقف الرفع")
                elif k == "error":
                    self._link(False)
                    self.msg_var.set(e.get("why", "خطأ")); self._idle()
        except queue.Empty:
            pass
        self.root.after(120, self.drain)


if __name__ == "__main__":
    _k = enable_dpi()                     # BEFORE Tk(), or Windows stretches the window
    root = tk.Tk(); App(root, _k); root.mainloop()
