# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · the window
===============================
Tkinter on purpose: it ships with Python, so there is nothing to install and no PyInstaller .exe
to be quarantined by antivirus.

Design notes, because the first version was criticised fairly:
  • Colours are the app's OWN brand tokens (read from assets/app.css), not approximations, so the
    tool looks like part of the system rather than a utility bolted on.
  • Everything lives in a CENTRED column with a maximum width. Tk stretches widgets to fill by
    default, which is why maximising the first version looked broken — a full-screen window now
    just gets more margin, exactly as the web app does.
  • Type has a real hierarchy (title / label / data), and numbers are set in a monospace face so
    a changing count does not make the line jitter.
  • ADD FILES is a first-class button. Requiring the user to go to Explorer, copy files in, come
    back and press start is a worse flow than the drop zone it is replacing.
"""
from __future__ import annotations
import pathlib, queue, shutil, sys, threading, time, tkinter as tk
from tkinter import filedialog, ttk

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pump import Config, Pump                      # noqa: E402

# the app's own tokens (assets/app.css :root)
BG      = "#1b2930"
PANEL   = "#21403b"
CARD    = "#2c3533"
INK     = "#f7f4ec"
INK2    = "#dcd8cc"
MUTED   = "#a7ada6"
LINE    = "#3c4f4d"
COPPER  = "#dba875"
TEAL    = "#6fc0c0"
RED     = "#ff4d59"

UI   = "Segoe UI"
MONO = "Consolas"
MAXW = 620          # the content column never grows past this; maximising adds margin, not stretch


def enable_dpi():
    """Declare DPI awareness BEFORE Tk starts, or Windows renders the window at 96 DPI and
    bitmap-STRETCHES it to the display's scale. That stretch is what makes the text look blurry
    and the whole thing cheap — this screen runs at 120 DPI (1.25x), so every glyph was being
    resampled. Declared, Tk draws at native resolution and the type is sharp.

    Must run before the first tk.Tk(); called from both entry points. Returns the scale factor so
    pixel geometry can be scaled too — point-sized fonts Tk handles itself."""
    scale = 1.0
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor v2 (Win 8.1+)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()           # fallback (Vista+)
        u = ctypes.windll.user32
        dc = u.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)         # LOGPIXELSX
        u.ReleaseDC(0, dc)
        scale = max(1.0, dpi / 96.0)
    except Exception:
        pass                                                    # not Windows, or no shcore
    return scale


class App:
    def __init__(self, root: tk.Tk, scale: float = 1.0):
        self.root = root
        self.k = scale                       # pixel geometry must follow the display scale
        px = lambda n: int(n * scale)
        self.px = px
        root.title("ICCMC · أداة الرفع")
        root.configure(bg=BG)
        root.geometry(f"{px(700)}x{px(560)}")
        root.minsize(px(560), px(500))

        try:
            self.cfg, self.err = Config(HERE / "pump.ini"), None
        except SystemExit as e:
            self.cfg, self.err = None, str(e)

        self.pump = None
        self.events = queue.Queue()
        self.t0 = None
        self._style()

        # ── centred column ─────────────────────────────────────────────────
        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True)
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_columnconfigure(1, minsize=0)
        outer.grid_columnconfigure(2, weight=1)
        outer.grid_rowconfigure(0, weight=1)
        col = tk.Frame(outer, bg=BG)
        col.grid(row=0, column=1, sticky="n", pady=26)
        col.grid_columnconfigure(0, minsize=px(MAXW))

        # ── header ─────────────────────────────────────────────────────────
        head = tk.Frame(col, bg=BG); head.grid(row=0, column=0, sticky="ew", padx=4)
        tk.Label(head, text="أداة الرفع", bg=BG, fg=INK,
                 font=(UI, 21, "bold")).pack(anchor="e")
        tk.Label(head, text="ارفع دفعة كبيرة دون المتصفح — الطابور مجلد على قرصك",
                 bg=BG, fg=MUTED, font=(UI, 10)).pack(anchor="e", pady=(2, 0))
        tk.Frame(col, bg=LINE, height=1).grid(row=1, column=0, sticky="ew", pady=(16, 18), padx=4)

        # ── the folder card ────────────────────────────────────────────────
        card = tk.Frame(col, bg=CARD, highlightbackground=LINE, highlightthickness=1)
        card.grid(row=2, column=0, sticky="ew", padx=4)
        card.grid_columnconfigure(1, weight=1)
        inner = tk.Frame(card, bg=CARD, padx=16, pady=14)
        inner.pack(fill="x")
        inner.grid_columnconfigure(1, weight=1)

        tk.Button(inner, text="تغيير", command=self.pick, bg=CARD, fg=COPPER,
                  activebackground=CARD, activeforeground=COPPER, font=(UI, 9),
                  bd=1, relief="solid", padx=12, pady=3, cursor="hand2"
                  ).grid(row=0, column=0, rowspan=2, padx=(0, 14))
        self.folder_var = tk.StringVar(value=str(self.cfg.folder) if self.cfg else "—")
        tk.Label(inner, textvariable=self.folder_var, bg=CARD, fg=INK2, anchor="e",
                 font=(MONO, 9)).grid(row=0, column=1, sticky="ew")
        self.ready_var = tk.StringVar(value="")   # live count, refreshed by the folder watcher
        tk.Label(inner, textvariable=self.ready_var, bg=CARD, fg=TEAL, anchor="e",
                 font=(UI, 9)).grid(row=1, column=1, sticky="ew", pady=(3, 0))

        # ── add files · open folder ────────────────────────────────────────
        acts = tk.Frame(col, bg=BG); acts.grid(row=3, column=0, sticky="ew", pady=(12, 0), padx=4)
        self.add_btn = tk.Button(acts, text="＋  أضف ملفات", command=self.add_files,
                                 bg=BG, fg=COPPER, activebackground=BG, activeforeground=INK,
                                 font=(UI, 10, "bold"), bd=1, relief="solid",
                                 highlightbackground=COPPER,
                                 padx=px(20), pady=px(8), cursor="hand2")
        self.add_btn.pack(side="right")
        tk.Button(acts, text="افتح المجلد", command=self.open_folder, bg=BG, fg=MUTED,
                  activebackground=BG, activeforeground=COPPER, font=(UI, 9),
                  bd=0, cursor="hand2").pack(side="left")

        # ── progress ───────────────────────────────────────────────────────
        prog = tk.Frame(col, bg=BG); prog.grid(row=4, column=0, sticky="ew", pady=(24, 0), padx=4)
        self.count_var = tk.StringVar(value="—")
        tk.Label(prog, textvariable=self.count_var, bg=BG, fg=INK,
                 font=(MONO, 15, "bold")).pack(anchor="e")
        self.bar = ttk.Progressbar(prog, style="I.Horizontal.TProgressbar", maximum=100)
        self.bar.pack(fill="x", pady=(8, 6))
        self.rate_var = tk.StringVar(value="")
        tk.Label(prog, textvariable=self.rate_var, bg=BG, fg=MUTED,
                 font=(MONO, 9)).pack(anchor="e")

        self.safe = tk.Label(col, text="✓   يمكنك إغلاق المتصفح — الرفع مستمر",
                             bg=BG, fg=TEAL, font=(UI, 10, "bold"))
        self.safe.grid(row=5, column=0, sticky="e", pady=(18, 0), padx=4)
        self.safe.grid_remove()

        self.msg_var = tk.StringVar(
            value=self.err or "أضف ملفات ثم اضغط «ابدأ الرفع»")
        tk.Label(col, textvariable=self.msg_var, bg=BG, fg=(RED if self.err else MUTED),
                 wraplength=px(MAXW) - 20, justify="right", font=(UI, 9)
                 ).grid(row=6, column=0, sticky="e", pady=(14, 0), padx=4)

        # ── footer ─────────────────────────────────────────────────────────
        foot = tk.Frame(col, bg=BG); foot.grid(row=7, column=0, sticky="ew", pady=(26, 0), padx=4)
        self.go = tk.Button(foot, text="ابدأ الرفع", command=self.start,
                            bg=COPPER, fg="#1a1206", activebackground="#e8bd8e",
                            activeforeground="#1a1206", font=(UI, 12, "bold"),
                            bd=0, padx=px(30), pady=px(11), cursor="hand2")
        self.go.pack(side="right")
        self.stop_btn = tk.Button(foot, text="إيقاف", command=self.stop, bg=BG, fg=INK2,
                                  activebackground=BG, activeforeground=RED, font=(UI, 10),
                                  bd=1, relief="solid", padx=18, pady=9,
                                  state="disabled", cursor="hand2")
        self.stop_btn.pack(side="right", padx=(0, 10))

        if self.err:
            self.go.config(state="disabled"); self.add_btn.config(state="disabled")
        else:
            self.refresh_ready()
            self.watch_folder()          # the folder IS the queue — notice it changing
        self.root.after(120, self.drain)

    # ── styling ─────────────────────────────────────────────────────────────
    def _style(self):
        s = ttk.Style()
        try: s.theme_use("clam")            # the only built-in theme that honours custom colours
        except Exception: pass
        s.configure("I.Horizontal.TProgressbar", troughcolor=CARD, background=COPPER,
                    bordercolor=CARD, lightcolor=COPPER, darkcolor=COPPER,
                    thickness=int(10 * self.k))

    # ── state ───────────────────────────────────────────────────────────────
    def watch_folder(self):
        """Re-count every 1.5s while idle.

        You can put files in two ways — «＋ أضف ملفات», or by copying them into the folder in
        Explorer (which «افتح المجلد» opens for exactly that). The second way left the window
        showing a stale count until you clicked something, which makes the tool look broken when
        it is simply not looking. Cheap: one directory listing, and skipped entirely while a run
        is in progress, since the pump is moving those files itself."""
        try:
            if not (self.pump and not self.pump.stop.is_set()
                    and self.bar['value'] < self.bar['maximum']):
                self.refresh_ready()
        except Exception:
            pass
        self.root.after(1500, self.watch_folder)

    def refresh_ready(self):
        """How many files are actually sitting in the folder, waiting."""
        if not self.cfg: return 0
        try:
            self.cfg.folder.mkdir(parents=True, exist_ok=True)
            n = sum(1 for p in self.cfg.folder.iterdir()
                    if p.is_file() and not p.name.startswith("."))
        except Exception:
            n = 0
        self.ready_var.set(f"{n} ملف جاهز للرفع" if n else
                           "المجلد فارغ — اضغط «＋ أضف ملفات» أو انسخ ملفاتك إليه")
        # never re-enable Start mid-run; _idle() owns that when the run ends
        running = bool(self.pump and not self.pump.stop.is_set()
                       and self.bar['value'] < self.bar['maximum'])
        if not running:
            self.go.config(state=("normal" if n else "disabled"))
        return n

    # ── actions ─────────────────────────────────────────────────────────────
    def add_files(self):
        """Pick files from anywhere and copy them into the folder.

        Without this the flow was: leave the app, find the files in Explorer, copy them in, come
        back, press start — worse than the browser drop zone it replaces. Copying (not moving)
        is deliberate: the tool must never remove a file from wherever the user keeps it."""
        paths = filedialog.askopenfilenames(
            title="اختر الملفات",
            filetypes=[("كل الملفات المدعومة", "*.pdf *.jpg *.jpeg *.png *.webp *.xlsx *.docx"),
                       ("الكل", "*.*")])
        if not paths: return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        added = clash = 0
        for src in paths:
            src = pathlib.Path(src)
            dst = self.cfg.folder / src.name
            if dst.exists():                      # never silently overwrite a queued file
                stem, suf, i = dst.stem, dst.suffix, 2
                while dst.exists():
                    dst = self.cfg.folder / f"{stem} ({i}){suf}"; i += 1
                clash += 1
            try:
                shutil.copy2(src, dst); added += 1
            except Exception as e:
                self.msg_var.set(f"تعذّر نسخ {src.name}: {e}")
        n = self.refresh_ready()
        self.msg_var.set(f"أُضيف {added} ملف — المجموع {n}"
                         + (f" · {clash} بالاسم نفسه أُعيدت تسميتها" if clash else ""))

    def pick(self):
        d = filedialog.askdirectory(title="اختر مجلد الرفع")
        if d:
            self.cfg.folder = pathlib.Path(d)
            self.folder_var.set(d)
            self.refresh_ready()

    def open_folder(self):
        if not self.cfg: return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        import os; os.startfile(self.cfg.folder)                    # noqa: S606 (Windows)

    def start(self):
        if not self.cfg: return
        if self.pump and not self.pump.stop.is_set() and self.bar["value"] < self.bar["maximum"]:
            return                                                   # already running
        if not self.refresh_ready():
            self.msg_var.set("المجلد فارغ — أضف ملفات أولًا"); return
        # Asked on the machine, stored in the gitignored pump.ini — the password never travels
        # through a chat, a code edit or a diff. Asked once; later runs read the file.
        if not self.cfg.password:
            from tkinter import simpledialog
            pw = simpledialog.askstring("كلمة المرور",
                                        f"كلمة مرور {self.cfg.email}\n(تُحفظ في pump.ini على جهازك)",
                                        show="•", parent=self.root)
            if not pw:
                self.msg_var.set("لا يمكن الرفع بدون كلمة المرور"); return
            try: self.cfg.save_password(pw.strip())
            except Exception as e:
                self.msg_var.set(f"تعذّر حفظ كلمة المرور: {e}"); return
        self.pump = Pump(self.cfg, lambda **k: self.events.put(k))
        self.t0 = time.time()
        self.go.config(state="disabled"); self.add_btn.config(state="disabled")
        self.stop_btn.config(state="normal"); self.msg_var.set("")
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try: self.pump.run()
        except Exception as e:
            self.events.put({"kind": "error", "why": f"{type(e).__name__}: {e}"})

    def stop(self):
        if self.pump:
            self.pump.stop.set()
            self.msg_var.set("جارٍ الإيقاف… الملفات قيد الرفع تعود إلى المجلد")

    def _idle(self):
        self.safe.grid_remove()
        self.go.config(state="normal"); self.add_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.refresh_ready()

    # ── the event pump (worker threads never touch Tk) ──────────────────────
    def drain(self):
        try:
            while True:
                e = self.events.get_nowait(); k = e.get("kind")
                if k == "start":
                    self.bar["maximum"] = e["total"]; self.bar["value"] = 0
                    self.safe.grid(); self.msg_var.set(f"دفعة {e['batch']}")
                elif k in ("ok", "skip", "fail"):
                    p = self.pump; n = p.done + p.failed
                    self.bar["value"] = n
                    self.count_var.set(f"{n} / {p.total}")
                    mins = max((time.time() - self.t0) / 60, 1e-6)
                    self.rate_var.set(f"{n/mins:.0f}/دقيقة · فشل {p.failed}"
                                      + (f" · معروف مسبقًا {p.skipped}" if p.skipped else ""))
                elif k == "empty":
                    self.msg_var.set("المجلد فارغ — أضف ملفات ثم ابدأ"); self._idle()
                elif k == "finish":
                    self._idle()
                    msg = f"اكتمل {e['done']} · فشل {e['failed']}"
                    msg += (" — انظر مجلد _failed، مع سبب لكل ملف" if e["failed"]
                            else " — افتح الموقع مرة واحدة لتُودَع الملفات النظيفة")
                    self.msg_var.set(msg)
                elif k == "error":
                    self._idle(); self.msg_var.set(e["why"])
        except queue.Empty:
            pass
        self.root.after(120, self.drain)


if __name__ == "__main__":
    _k = enable_dpi()                     # BEFORE Tk(), or Windows stretches the window
    root = tk.Tk(); App(root, _k); root.mainloop()
