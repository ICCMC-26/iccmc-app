# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · the window
===============================
Tkinter on purpose: it ships with Python, so there is nothing to install and nothing to package.
A .exe built with PyInstaller would be one file, but those get flagged by antivirus — and this
machine's AV is aggressive enough to have made folders on the Desktop disappear.

The window says the thing that matters most, plainly: **you can close the browser.** People watch
a progress bar because they are afraid to leave; if the tool states the truth, they stop watching.
"""
from __future__ import annotations
import pathlib, queue, sys, threading, time, tkinter as tk
from tkinter import filedialog, ttk

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pump import Config, Pump                      # noqa: E402

BG, CARD, INK, MUTED, COPPER, RED, GREEN = "#12181c", "#1a2228", "#e8eaec", "#8b979e", "#c5956b", "#e05a5a", "#5fbf7f"


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("ICCMC · أداة الرفع")
        root.configure(bg=BG)
        root.geometry("560x400")
        root.minsize(520, 380)

        try:
            self.cfg = Config(HERE / "pump.ini")
            self.err = None
        except SystemExit as e:
            self.cfg, self.err = None, str(e)

        self.pump = None
        self.events = queue.Queue()
        self.t0 = None

        wrap = tk.Frame(root, bg=BG, padx=22, pady=18)
        wrap.pack(fill="both", expand=True)

        tk.Label(wrap, text="أداة الرفع · ICCMC", bg=BG, fg=INK,
                 font=("Segoe UI", 16, "bold")).pack(anchor="e")
        tk.Label(wrap, text="ارفع دفعة كبيرة دون المتصفح", bg=BG, fg=MUTED,
                 font=("Segoe UI", 10)).pack(anchor="e", pady=(0, 14))

        # folder
        fr = tk.Frame(wrap, bg=CARD, padx=12, pady=10)
        fr.pack(fill="x")
        self.folder_var = tk.StringVar(value=str(self.cfg.folder) if self.cfg else "—")
        tk.Label(fr, textvariable=self.folder_var, bg=CARD, fg=INK, anchor="w",
                 font=("Consolas", 9)).pack(side="left", fill="x", expand=True)
        tk.Button(fr, text="تغيير", command=self.pick, bg=CARD, fg=COPPER, bd=1,
                  relief="solid", padx=10, cursor="hand2").pack(side="right")

        # counts
        self.count_var = tk.StringVar(value="—")
        tk.Label(wrap, textvariable=self.count_var, bg=BG, fg=INK,
                 font=("Consolas", 11)).pack(anchor="e", pady=(16, 4))

        self.bar = ttk.Progressbar(wrap, maximum=100, length=100)
        self.bar.pack(fill="x", pady=(0, 6))

        self.rate_var = tk.StringVar(value="")
        tk.Label(wrap, textvariable=self.rate_var, bg=BG, fg=MUTED,
                 font=("Consolas", 9)).pack(anchor="e")

        # the reassurance — the whole point of the tool
        self.safe = tk.Label(wrap, text="✓  يمكنك إغلاق المتصفح — الرفع مستمر",
                             bg=BG, fg=GREEN, font=("Segoe UI", 10))
        self.safe.pack(anchor="e", pady=(14, 0))
        self.safe.pack_forget()

        self.msg_var = tk.StringVar(value=self.err or "اسحب ملفاتك إلى المجلد، ثم اضغط «ابدأ الرفع»")
        tk.Label(wrap, textvariable=self.msg_var, bg=BG, fg=(RED if self.err else MUTED),
                 wraplength=500, justify="right", font=("Segoe UI", 9)).pack(anchor="e", pady=(10, 0))

        btns = tk.Frame(wrap, bg=BG)
        btns.pack(side="bottom", fill="x", pady=(16, 0))
        self.go = tk.Button(btns, text="ابدأ الرفع", command=self.start, bg=COPPER, fg="#1a1206",
                            font=("Segoe UI", 11, "bold"), bd=0, padx=22, pady=9, cursor="hand2")
        self.go.pack(side="right")
        self.stop_btn = tk.Button(btns, text="إيقاف", command=self.stop, bg=CARD, fg=INK, bd=1,
                                  relief="solid", padx=16, pady=8, state="disabled", cursor="hand2")
        self.stop_btn.pack(side="right", padx=(0, 8))
        tk.Button(btns, text="افتح المجلد", command=self.open_folder, bg=BG, fg=MUTED, bd=0,
                  cursor="hand2").pack(side="left")

        if self.err:
            self.go.config(state="disabled")
        self.root.after(120, self.drain)

    # ── actions ─────────────────────────────────────────────────────────────
    def pick(self):
        d = filedialog.askdirectory(title="اختر مجلد الرفع")
        if d:
            self.cfg.folder = pathlib.Path(d)
            self.folder_var.set(d)

    def open_folder(self):
        if not self.cfg:
            return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        import os
        os.startfile(self.cfg.folder)                              # noqa: S606 (Windows)

    def start(self):
        if not self.cfg or (self.pump and not self.pump.stop.is_set() and self.bar["value"] < 100):
            return
        # Ask on the machine, store in the gitignored pump.ini — the password never travels
        # through a chat, a code edit or a diff. Asked once; every later run reads the file.
        if not self.cfg.password:
            from tkinter import simpledialog
            pw = simpledialog.askstring("كلمة المرور",
                                        f"كلمة مرور {self.cfg.email}\n(تُحفظ في pump.ini على جهازك)",
                                        show="•", parent=self.root)
            if not pw:
                self.msg_var.set("لا يمكن الرفع بدون كلمة المرور")
                return
            try:
                self.cfg.save_password(pw.strip())
            except Exception as e:
                self.msg_var.set(f"تعذّر حفظ كلمة المرور: {e}")
                return
        self.pump = Pump(self.cfg, lambda **k: self.events.put(k))
        self.t0 = time.time()
        self.go.config(state="disabled"); self.stop_btn.config(state="normal")
        self.msg_var.set("")
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            self.pump.run()
        except Exception as e:
            self.events.put({"kind": "error", "why": f"{type(e).__name__}: {e}"})

    def stop(self):
        if self.pump:
            self.pump.stop.set()
            self.msg_var.set("جارٍ الإيقاف… الملفات قيد الرفع تعود إلى المجلد")

    # ── the event pump (worker threads never touch Tk) ──────────────────────
    def drain(self):
        try:
            while True:
                e = self.events.get_nowait()
                k = e.get("kind")
                if k == "start":
                    self.bar["maximum"] = e["total"]
                    self.safe.pack(anchor="e", pady=(14, 0))
                    self.msg_var.set(f"دفعة {e['batch']}")
                elif k in ("ok", "skip", "fail"):
                    p = self.pump
                    n = p.done + p.failed
                    self.bar["value"] = n
                    self.count_var.set(f"{n} / {p.total}")
                    mins = max((time.time() - self.t0) / 60, 1e-6)
                    self.rate_var.set(f"{n/mins:.0f}/دقيقة · فشل {p.failed}"
                                      + (f" · معروف مسبقًا {p.skipped}" if p.skipped else ""))
                elif k == "empty":
                    self.msg_var.set("المجلد فارغ — أضِف ملفات ثم ابدأ")
                    self.go.config(state="normal"); self.stop_btn.config(state="disabled")
                elif k == "finish":
                    self.safe.pack_forget()
                    self.go.config(state="normal"); self.stop_btn.config(state="disabled")
                    msg = f"اكتمل {e['done']} · فشل {e['failed']}"
                    if e["failed"]:
                        msg += " — انظر مجلد _failed، مع سبب لكل ملف"
                    else:
                        msg += " — افتح الموقع لتُودَع الملفات النظيفة"
                    self.msg_var.set(msg)
                elif k == "error":
                    self.safe.pack_forget()
                    self.msg_var.set(e["why"])
                    self.go.config(state="normal"); self.stop_btn.config(state="disabled")
        except queue.Empty:
            pass
        self.root.after(120, self.drain)


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
