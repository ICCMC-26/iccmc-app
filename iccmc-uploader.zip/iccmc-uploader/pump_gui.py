# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · the window
===============================
Tkinter on purpose: it ships with Python, so there is nothing to install and no PyInstaller .exe
to be quarantined by antivirus.

Design notes, because the first version was criticised fairly:
  • Colours are the app's OWN brand tokens (read from assets/app.css), not approximations, so the
    tool looks like part of the system rather than a utility bolted on.
  • Everything lives in a CENTRED column with a maximum width. Tk stretches widgets to fill by
    default, which is why maximising the first version looked broken — a full-screen window now
    just gets more margin, exactly as the web app does.
  • Type has a real hierarchy (title / label / data), and numbers are set in a monospace face so
    a changing count does not make the line jitter.
  • ADD FILES is a first-class button. Requiring the user to go to Explorer, copy files in, come
    back and press start is a worse flow than the drop zone it is replacing.
"""
from __future__ import annotations
import pathlib, queue, shutil, sys, threading, time, tkinter as tk
from tkinter import filedialog, ttk

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import dnd
from pump import Config, Pump                      # noqa: E402

# the app's own tokens (assets/app.css :root)
BG      = "#1b2930"
PANEL   = "#21403b"
CARD    = "#2c3533"
INK     = "#f7f4ec"
INK2    = "#dcd8cc"
MUTED   = "#a7ada6"
LINE    = "#3c4f4d"
COPPER  = "#dba875"
TEAL    = "#6fc0c0"
RED     = "#ff4d59"

UI   = "Segoe UI"
MONO = "Consolas"
NL   = chr(10)          # newlines are built explicitly rather than escaped
MAXW = 620          # the content column never grows past this; maximising adds margin, not stretch


def enable_dpi():
    """Declare DPI awareness BEFORE Tk starts, or Windows renders the window at 96 DPI and
    bitmap-STRETCHES it to the display's scale. That stretch is what makes the text look blurry
    and the whole thing cheap — this screen runs at 120 DPI (1.25x), so every glyph was being
    resampled. Declared, Tk draws at native resolution and the type is sharp.

    Must run before the first tk.Tk(); called from both entry points. Returns the scale factor so
    pixel geometry can be scaled too — point-sized fonts Tk handles itself."""
    scale = 1.0
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor v2 (Win 8.1+)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()           # fallback (Vista+)
        u = ctypes.windll.user32
        dc = u.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)         # LOGPIXELSX
        u.ReleaseDC(0, dc)
        scale = max(1.0, dpi / 96.0)
    except Exception:
        pass                                                    # not Windows, or no shcore
    return scale


def _btn(parent, text, cmd, *, kind="ghost", font=None, padx=16, pady=8):
    """A flat button with a HOVER state.

    Tk buttons default to a raised 3-D border and no hover feedback, which is most of why the
    window read as dated. Flat + a colour shift on hover is what the web app does, and it is the
    single biggest change in making this feel like the same product.

      filled → the one primary action     ghost → secondary     quiet → tertiary/text
    """
    look = {"filled": dict(bg=COPPER, fg="#1a1206", hbg="#e9bd8f", hfg="#1a1206"),
            "ghost":  dict(bg=BG,     fg=COPPER,    hbg=CARD,      hfg=INK),
            "quiet":  dict(bg=BG,     fg=MUTED,     hbg=BG,        hfg=COPPER)}[kind]
    b = tk.Button(parent, text=text, command=cmd, bd=0, relief="flat",
                  highlightthickness=0, activebackground=look["hbg"],
                  activeforeground=look["hfg"], bg=look["bg"], fg=look["fg"],
                  font=font or (UI, 10), padx=padx, pady=pady, cursor="hand2")
    def on(_):  b.config(bg=look["hbg"], fg=look["hfg"])
    def off(_):
        if str(b["state"]) != "disabled": b.config(bg=look["bg"], fg=look["fg"])
    b.bind("<Enter>", on); b.bind("<Leave>", off)
    b._look = look
    return b


class App:
    def __init__(self, root: tk.Tk, scale: float = 1.0):
        self.root = root
        self.k = scale                       # pixel geometry must follow the display scale
        px = lambda n: int(n * scale)
        self.px = px
        root.title("ICCMC · أداة الرفع")
        root.configure(bg=BG)
        root.geometry(f"{px(720)}x{px(780)}")
        root.minsize(px(560), px(620))

        try:
            self.cfg, self.err = Config(HERE / "pump.ini"), None
        except SystemExit as e:
            self.cfg, self.err = None, str(e)

        self.pump = None
        self.events = queue.Queue()
        self.t0 = None
        # ONE explicit flag for "a run is in progress". This used to be inferred from the progress
        # bar (pump exists AND value < maximum), which silently lied after a failed sign-in: the
        # pump object lingered, stop was never set, and the bar sat at 0/100 because the 'start'
        # event never fired — so Start believed a run was active and did NOTHING when pressed.
        # State that matters is never read back out of a widget.
        self.running = False
        self.reading = False          # phase 2: the worker is reading what we sent
        self._read_txt = ""
        self._style()

        # ── centred column ─────────────────────────────────────────────────
        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True)
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_columnconfigure(1, minsize=0)
        outer.grid_columnconfigure(2, weight=1)
        outer.grid_rowconfigure(0, weight=1)
        col = tk.Frame(outer, bg=BG)
        col.grid(row=0, column=1, sticky="n", pady=26)
        col.grid_columnconfigure(0, minsize=px(MAXW))

        # ── header ─────────────────────────────────────────────────────────
        head = tk.Frame(col, bg=BG); head.grid(row=0, column=0, sticky="ew", padx=4)
        tk.Label(head, text="أداة الرفع", bg=BG, fg=INK,
                 font=(UI, 21, "bold")).pack(anchor="e")
        tk.Label(head, text="ارفع دفعة كبيرة دون المتصفح — الطابور مجلد على قرصك",
                 bg=BG, fg=MUTED, font=(UI, 10)).pack(anchor="e", pady=(2, 0))
        tk.Frame(col, bg=LINE, height=1).grid(row=1, column=0, sticky="ew", pady=(16, 18), padx=4)

        # ── the drop zone ──────────────────────────────────────────────────
        # This IS the queue. Everything about it answers one question — where do the files go —
        # so the invitation leads, the live count confirms, and the folder path sits underneath
        # as the quiet detail it is (it matters only when you want to copy files in by hand).
        card = tk.Frame(col, bg=CARD, highlightthickness=1,
                        highlightbackground=LINE, highlightcolor=LINE)
        card.grid(row=2, column=0, sticky="ew", padx=4)

        zone = tk.Frame(card, bg=CARD, pady=px(16))
        zone.pack(fill="x")
        self.drop_lbl = tk.Label(zone, text="أفلِت الملفات هنا", bg=CARD, fg=INK,
                                 font=(UI, 13, "bold"))
        self.drop_lbl.pack()
        self.hint_lbl = tk.Label(zone, text="أو استخدم الأزرار بالأسفل: اختر ملفات، أو اختر مجلداً كاملاً",
                                 bg=CARD, fg=MUTED, font=(UI, 9))
        self.hint_lbl.pack(pady=(4, 0))
        self.ready_var = tk.StringVar(value="")   # live count, refreshed by the folder watcher
        tk.Label(zone, textvariable=self.ready_var, bg=CARD, fg=TEAL,
                 font=(UI, 11, "bold")).pack(pady=(px(14), 0))

        tk.Frame(card, bg=LINE, height=1).pack(fill="x")
        foot_c = tk.Frame(card, bg=CARD, padx=14, pady=8); foot_c.pack(fill="x")
        chg = _btn(foot_c, "تغيير", self.pick, kind="quiet", font=(UI, 8), padx=px(8), pady=px(3))
        chg.pack(side="left")
        _btn(foot_c, "افتح", self.open_folder, kind="quiet", font=(UI, 8),
             padx=px(8), pady=px(3)).pack(side="left", padx=(px(6), 0))
        self.folder_var = tk.StringVar(value=str(self.cfg.folder) if self.cfg else "—")
        tk.Label(foot_c, textvariable=self.folder_var, bg=CARD, fg=MUTED, anchor="e",
                 font=(MONO, 8)).pack(side="right")

        # ── add files ──────────────────────────────────────────────────────
        acts = tk.Frame(col, bg=BG); acts.grid(row=3, column=0, sticky="ew", pady=(12, 0), padx=4)
        self.add_btn = _btn(acts, "اختر ملفات", self.add_files, kind="ghost",
                            font=(UI, 10, "bold"), padx=px(22), pady=px(10))
        self.add_btn.pack(side="right")
        self.fold_btn = _btn(acts, "اختر مجلداً", self.add_folder, kind="ghost",
                             font=(UI, 10), padx=px(18), pady=px(10))
        self.fold_btn.pack(side="right", padx=(0, px(8)))
        self.again_btn = _btn(acts, "↺  أعِد إرسال المُرسَل", self.resend, kind="quiet",
                              font=(UI, 9), padx=0, pady=px(10))
        self.again_btn.pack(side="left")

        # ── the list ───────────────────────────────────────────────────────
        # The same shape as the web intake: one row per file, its own state on it, and a مُوجز
        # view that collapses everything already settled so only what needs a human stays. A
        # single bar could say "12 / 30" but never "which twelve" — and not knowing which is
        # exactly what makes a big upload feel like guesswork.
        self.wrap = tk.Frame(col, bg=BG)
        self.wrap.grid(row=4, column=0, sticky="ew", pady=(20, 0), padx=4)

        self.sum_c = tk.Canvas(self.wrap, height=self.px(6), bg=BG, highlightthickness=0)
        self.sum_c.pack(fill="x")
        legend = tk.Frame(self.wrap, bg=BG); legend.pack(fill="x", pady=(8, 0))
        self.legend = legend
        self.view_btn = _btn(legend, "", self.toggle_view, kind="quiet",
                             font=(UI, 9), padx=0, pady=self.px(2))
        self.view_btn.pack(side="left")
        self.legend_var = tk.StringVar(value="")
        tk.Label(legend, textvariable=self.legend_var, bg=BG, fg=MUTED, anchor="e",
                 font=(UI, 9)).pack(side="right")

        holder = tk.Frame(self.wrap, bg=BG); holder.pack(fill="both", expand=True, pady=(10, 0))
        self.canvas = tk.Canvas(holder, bg=BG, highlightthickness=0, height=self.px(230))
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="left", fill="y"); self.canvas.pack(side="right", fill="both", expand=True)
        self.rows_f = tk.Frame(self.canvas, bg=BG)
        self._win = self.canvas.create_window((0, 0), window=self.rows_f, anchor="nw")
        self.rows_f.bind("<Configure>",
                         lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfig(self._win, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._wheel)

        self.rows = []          # [{name, mb, state, hash, why}] — the run, in order
        self._widgets = {}      # name → (frame, state label) so a row repaints without a rebuild
        self._view = "auto"     # auto | compact | detailed — the count picks, the user overrides
        self.wrap.grid_remove()             # appears only once there is a list to show

        self.read_var = tk.StringVar(value="")
        self.read_lbl = tk.Label(col, textvariable=self.read_var, bg=BG, fg=TEAL,
                                 font=(UI, 10, "bold"))
        self.read_lbl.grid(row=8, column=0, sticky="e", pady=(10, 0), padx=4)
        self.read_lbl.grid_remove()
        self._spin_i = 0

        self.safe = tk.Label(col, text="✓   يمكنك إغلاق المتصفح — الرفع مستمر",
                             bg=BG, fg=TEAL, font=(UI, 10, "bold"))
        self.safe.grid(row=5, column=0, sticky="e", pady=(18, 0), padx=4)
        self.safe.grid_remove()

        self.msg_var = tk.StringVar(
            value=self.err or "أضف ملفات ثم اضغط «ابدأ الرفع»")
        self.msg_lbl = tk.Label(col, textvariable=self.msg_var, bg=BG, fg=(RED if self.err else MUTED),
                 wraplength=self.px(MAXW) - 20, justify="right", font=(UI, 9))
        self.msg_lbl.grid(row=6, column=0, sticky="e", pady=(14, 0), padx=4)

        # ── footer ─────────────────────────────────────────────────────────
        foot = tk.Frame(col, bg=BG); foot.grid(row=7, column=0, sticky="ew", pady=(26, 0), padx=4)
        self.go = _btn(foot, "ابدأ الرفع", self.start, kind="filled",
                       font=(UI, 12, "bold"), padx=self.px(32), pady=self.px(12))
        self.go.pack(side="right")
        self.stop_btn = _btn(foot, "إيقاف", self.stop, kind="ghost",
                             font=(UI, 10), padx=self.px(20), pady=self.px(12))
        self.stop_btn.config(state="disabled", fg=LINE)      # visibly inert until a run starts
        self.stop_btn.pack(side="right", padx=(0, self.px(10)))

        if self.err:
            # a tool that cannot reach its config must not offer any door into the queue
            self.go.config(state="disabled"); self.add_btn.config(state="disabled")
            self.fold_btn.config(state="disabled")
        else:
            self.refresh_ready()
            self.watch_folder()          # the folder IS the queue — notice it changing
            if not dnd.enable(self.root, self.on_drop):
                # never advertise a gesture this machine cannot do
                self.drop_lbl.config(text="أضف ملفاتك إلى الطابور", font=(UI, 13, "bold"))
                self.hint_lbl.config(text="استخدم الأزرار بالأسفل: اختر ملفات، أو اختر مجلداً كاملاً")
        self.root.after(120, self.drain)

    # ── styling ─────────────────────────────────────────────────────────────
    def _style(self):
        s = ttk.Style()
        try: s.theme_use("clam")            # the only built-in theme that honours custom colours
        except Exception: pass
        s.configure("I.Horizontal.TProgressbar", troughcolor=CARD, background=COPPER,
                    bordercolor=CARD, lightcolor=COPPER, darkcolor=COPPER,
                    thickness=int(10 * self.k))

    # ── state ───────────────────────────────────────────────────────────────
    def watch_folder(self):
        """Re-count every 1.5s while idle.

        You can put files in two ways — «＋ أضف ملفات», or by copying them into the folder in
        Explorer (which «افتح المجلد» opens for exactly that). The second way left the window
        showing a stale count until you clicked something, which makes the tool look broken when
        it is simply not looking. Cheap: one directory listing, and skipped entirely while a run
        is in progress, since the pump is moving those files itself."""
        try:
            if not self.running:
                self.refresh_ready()
        except Exception:
            pass
        self.root.after(1500, self.watch_folder)

    def refresh_ready(self):
        """How many files are actually sitting in the folder, waiting."""
        if not self.cfg: return 0
        try:
            self.cfg.folder.mkdir(parents=True, exist_ok=True)
            n = sum(1 for p in self.cfg.folder.iterdir()
                    if p.is_file() and not p.name.startswith("."))
        except Exception:
            n = 0
        # the zone above already says how to add; the count only has to say how many
        self.ready_var.set(f"{n} ملف جاهز للرفع" if n else "الطابور فارغ")
        # never re-enable Start mid-run; _idle() owns that when the run ends
        if not self.running:
            self.go.config(state=("normal" if n else "disabled"))
        return n

    # ── the list ────────────────────────────────────────────────────────────
    # Same words the website uses, so a file means the same thing in both places.
    ST_TXT = {"queued": "بالانتظار", "up": "يُرفع…", "sent": "قيد المعالجة",
              "committed": "أُودِعت", "review": "للمراجعة", "refused": "مرفوض",
              "failed": "فشل", "skip": "مُرسَل سابقًا"}
    ST_COL = {"queued": MUTED, "up": COPPER, "sent": COPPER, "committed": TEAL,
              "review": COPPER, "refused": RED, "failed": RED, "skip": MUTED}
    DONE = ("committed", "review", "refused", "failed", "skip")
    NEEDS_ME = ("review", "refused", "failed")
    COMPACT_AT = 20          # a screenful; past this the settled rows collapse by default
    CAP = 200                # never build more widgets than a human can scroll

    def _wheel(self, e):
        try:
            self.canvas.yview_scroll(int(-e.delta / 120), "units")
        except Exception:
            pass

    def toggle_view(self):
        self._view = "detailed" if self._compact() else "compact"
        self.render_list()

    def _compact(self):
        return self._view == "compact" or (self._view == "auto" and len(self.rows) >= self.COMPACT_AT)

    def add_rows(self, names):
        """Seed the list from the folder the moment a run starts — every file visible up front."""
        self.rows = [{"name": n, "mb": mb, "state": "queued", "hash": None, "why": ""}
                     for n, mb in names]
        self._widgets = {}
        self.wrap.grid()
        self.render_list()

    def set_row(self, name, **kw):
        for r in self.rows:
            if r["name"] == name:
                r.update(kw); return r
        return None

    def apply_rows(self, ledger):
        """Fold the server's per-file buckets back onto the list.

        The tool knows a file by name; the ledger knows it by content hash. The upload step
        recorded the hash for exactly this moment — without it the list could only ever show what
        LEAVING looked like, never what ARRIVING looked like.
        """
        by_hash = {r.get("hash"): r for r in self.rows if r.get("hash")}
        for row in ledger or []:
            r = by_hash.get(row.get("image_hash"))
            if not r:
                continue
            b = (row.get("bucket") or "").strip()
            if b == "committed":   r["state"] = "committed"
            elif b == "review":    r["state"] = "review"
            elif b == "refused":
                r["state"] = "refused"
                r["why"] = (row.get("fail_reason") or "").strip()
            r["doc"] = (row.get("doc_type") or "").strip()
        self.render_list()

    def _counts(self):
        c = {k: 0 for k in ("queued", "up", "sent", "committed", "review", "refused",
                            "failed", "skip")}
        for r in self.rows:
            c[r["state"]] = c.get(r["state"], 0) + 1
        return c

    def render_list(self):
        if not self.rows:
            self.wrap.grid_remove(); return
        self.wrap.grid()
        c = self._counts()
        done = c["committed"] + c["skip"]
        busy = c["queued"] + c["up"] + c["sent"]
        compact = self._compact()

        # the summary bar: the whole run in one line, in the same colours as the chips
        self.sum_c.delete("all")
        w = max(self.sum_c.winfo_width(), 1); total = max(len(self.rows), 1)
        x = 0
        for key, n in (("committed", done), ("review", c["review"]),
                       ("refused", c["refused"] + c["failed"]), ("queued", busy)):
            if not n: continue
            seg = w * n / total
            self.sum_c.create_rectangle(x, 0, x + seg, self.px(6), fill=self.ST_COL[key], width=0)
            x += seg

        bits = [f"{done} أُودِعت"]
        if c["review"]:  bits.append(f"{c['review']} للمراجعة")
        if c["refused"] + c["failed"]: bits.append(f"{c['refused'] + c['failed']} مرفوض")
        if busy:         bits.append(f"{busy} جارٍ")
        self.legend_var.set("  ·  ".join(bits) + f"   —   {len(self.rows)} ملف")
        self.view_btn.config(text=("تفصيلي ›" if compact else "مُوجز ›"))

        # COMPACT shows only what a human must act on; everything settled is already in the bar
        shown = [r for r in self.rows if r["state"] in self.NEEDS_ME] if compact else self.rows
        extra = max(0, len(shown) - self.CAP)
        shown = shown[:self.CAP]

        for ch in self.rows_f.winfo_children():
            ch.destroy()
        if not shown:
            tk.Label(self.rows_f, bg=BG, fg=TEAL, font=(UI, 10, "bold"),
                     text=("أُودِعت كلها ✓" if not busy else "…جارٍ الرفع")
                     ).pack(anchor="e", pady=self.px(18))
        for r in shown:
            self._row_widget(r)
        if extra:
            tk.Label(self.rows_f, text=f"…و {extra} أخرى", bg=BG, fg=MUTED,
                     font=(UI, 9)).pack(anchor="e", pady=(6, 0))
        self.rows_f.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _row_widget(self, r):
        f = tk.Frame(self.rows_f, bg=CARD)
        f.pack(fill="x", pady=(0, self.px(4)))
        inner = tk.Frame(f, bg=CARD, padx=self.px(12), pady=self.px(8)); inner.pack(fill="x")
        tk.Label(inner, text=self.ST_TXT.get(r["state"], r["state"]), bg=CARD,
                 fg=self.ST_COL.get(r["state"], MUTED), font=(UI, 9, "bold")
                 ).pack(side="left")
        txt = tk.Frame(inner, bg=CARD); txt.pack(side="right", fill="x", expand=True)
        tk.Label(txt, text=r["name"], bg=CARD, fg=INK, anchor="e",
                 font=(UI, 10)).pack(fill="x")
        sub = f"{r['mb']:.1f} MB"
        if r["state"] == "review":   sub += " · بانتظارك في «الوارد»"
        elif r["state"] == "refused" and r.get("why"): sub += f" · {r['why'][:60]}"
        elif r.get("doc"):           sub += f" · {r['doc']}"
        tk.Label(txt, text=sub, bg=CARD, fg=MUTED, anchor="e",
                 font=(UI, 8)).pack(fill="x")


    # ── actions ─────────────────────────────────────────────────────────────
    def add_folder(self):
        """Choose a folder — everything inside it joins the queue.

        Scans arrive as folders. Making the user open the folder and select its contents by hand
        was busywork the tool can simply do."""
        d = filedialog.askdirectory(title="اختر مجلداً — سيُرفع كل ما فيه")
        if d:
            self.on_drop([d])

    def add_files(self):
        """Pick files from anywhere and copy them into the folder."""
        paths = filedialog.askopenfilenames(
            title="اختر الملفات",
            filetypes=[("كل الملفات المدعومة", "*.pdf *.jpg *.jpeg *.png *.webp *.xlsx *.docx"),
                       ("الكل", "*.*")])
        if paths:
            self._ingest(paths)

    def on_drop(self, paths):
        """Files (or folders) dragged onto the window.

        Dropping is the first thing anyone tries on a tool that replaces a browser drop zone, and
        until now nothing happened — the only ways in were a file dialog or Explorer. A dropped
        FOLDER is expanded, because scans arrive as folders far more often than as loose files."""
        out = []
        for raw in paths:
            q = pathlib.Path(raw)
            if q.is_dir():
                out += [x for x in sorted(q.rglob("*"))
                        if x.is_file() and not x.name.startswith(".")]
            elif q.is_file():
                out.append(q)
        if out:
            self._ingest(out)
        else:
            self.msg_var.set("لا توجد ملفات في ما أُفلِت")

    def _ingest(self, paths):
        """Copy chosen files into the queue folder — the one way in, whatever the door.

        Copying (not moving) is deliberate: the tool must never remove a file from wherever the
        user keeps it. A name already queued is renamed rather than overwritten, because silently
        replacing a file that is waiting to be sent would lose it."""
        if self.running:
            self.msg_var.set("الرفع جارٍ — انتظر انتهاءه ثم أضف")
            return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        added = clash = 0
        for src in paths:
            src = pathlib.Path(src)
            dst = self.cfg.folder / src.name
            if dst.exists():
                stem, suf, i = dst.stem, dst.suffix, 2
                while dst.exists():
                    dst = self.cfg.folder / f"{stem} ({i}){suf}"; i += 1
                clash += 1
            try:
                shutil.copy2(src, dst); added += 1
            except Exception as e:
                self.msg_var.set(f"تعذّر نسخ {src.name}: {e}")
        n = self.refresh_ready()
        self._link(False)
        self.msg_var.set(f"أُضيف {added} ملف — المجموع {n}"
                         + (f" · {clash} بالاسم نفسه أُعيدت تسميتها" if clash else ""))

    def resend(self):
        """Move everything in _done back into the folder, so it can be sent again.

        A file the uploader has handled lives in _done, which is what makes a restart safe — but
        it also meant there was NO WAY to re-send. Deleting a card in the app and re-running the
        uploader did nothing, because the folder was empty and the tool had no reason to say so.
        The queue is a folder, so re-queueing has to be a folder move.

        The system still refuses genuine duplicates by content hash — this only gives the file
        another chance to be OFFERED. If its row was deleted in the app it will be read afresh;
        if not, it is skipped as already known, which is the correct answer either way."""
        done = self.cfg.folder / "_done"
        if not done.exists():
            self.msg_var.set("لا شيء أُرسل بعد"); return
        files = [f for f in done.iterdir() if f.is_file()]
        if not files:
            self.msg_var.set("لا شيء في «_done» لإعادة إرساله"); return
        moved = 0
        for f in files:
            dst = self.cfg.folder / f.name
            if dst.exists():
                stem, suf, i = dst.stem, dst.suffix, 2
                while dst.exists():
                    dst = self.cfg.folder / f"{stem} ({i}){suf}"; i += 1
            try:
                shutil.move(str(f), str(dst)); moved += 1
            except Exception as e:
                self.msg_var.set(f"تعذّر نقل {f.name}: {e}"); break
        n = self.refresh_ready()
        self.msg_var.set(f"أُعيد {moved} ملف إلى الطابور — المجموع {n}. "
                         f"المكرّر فعليًا سيُتخطّى تلقائيًا.")

    def pick(self):
        d = filedialog.askdirectory(title="اختر مجلد الرفع")
        if d:
            self.cfg.folder = pathlib.Path(d)
            self.folder_var.set(d)
            self.refresh_ready()

    def open_folder(self):
        if not self.cfg: return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        import os; os.startfile(self.cfg.folder)                    # noqa: S606 (Windows)

    def start(self):
        if not self.cfg: return
        if self.running:
            return                                                   # already running
        if not self.refresh_ready():
            self.msg_var.set("المجلد فارغ — أضف ملفات أولًا"); return
        # Asked on the machine, stored in the gitignored pump.ini — the password never travels
        # through a chat, a code edit or a diff. Asked once; later runs read the file.
        if not self.cfg.password:
            from tkinter import simpledialog
            pw = simpledialog.askstring("كلمة المرور",
                                        f"كلمة مرور {self.cfg.email}\n(تُحفظ في pump.ini على جهازك)",
                                        show="•", parent=self.root)
            if not pw:
                self.msg_var.set("لا يمكن الرفع بدون كلمة المرور"); return
            try: self.cfg.save_password(pw.strip())
            except Exception as e:
                self.msg_var.set(f"تعذّر حفظ كلمة المرور: {e}"); return
        if not self._ask_about_known():
            return
        self.pump = Pump(self.cfg, lambda **k: self.events.put(k))
        self.t0 = time.time()
        self.running = True
        self.go.config(state="disabled"); self.add_btn.config(state="disabled")
        self.fold_btn.config(state="disabled")
        self.stop_btn.config(state="normal"); self.msg_var.set("")
        # every file on screen BEFORE anything moves — the list is the promise, then the record
        try:
            self.add_rows(sorted((f.name, f.stat().st_size / 1048576)
                                 for f in self.cfg.folder.iterdir()
                                 if f.is_file() and not f.name.startswith(".")))
        except Exception:
            pass
        threading.Thread(target=self._run, daemon=True).start()

    def _ask_about_known(self):
        """Before uploading, say plainly which files the system already has, and let the user choose.

        The uploader used to skip known content silently — so re-adding files looked like nothing
        happened, and the tool felt disconnected from «الوارد». Now it tells you, and «ارفعها
        مجددًا» forgets their rows first, because the line dedups by hash and a re-drop is
        otherwise a no-op. A COMMITTED file is never forgotten — that is an employee record.
        """
        import hashlib
        from tkinter import messagebox
        try:
            files = [f for f in self.cfg.folder.iterdir()
                     if f.is_file() and not f.name.startswith(".")]
            if not files:
                return True
            shas = {}
            for f in files:
                h = hashlib.sha256(); 
                with f.open("rb") as fh:
                    for c in iter(lambda: fh.read(1 << 20), b""): h.update(c)
                shas[f.name] = h.hexdigest()
            api = __import__("pump").Api(self.cfg)
            known = api.known_hashes(list(set(shas.values())))
            if not known:
                return True
            dupes = {n: known[h] for n, h in shas.items() if h in known}
            committed = [n for n, st in dupes.items() if st in ("done", "committed")]
            msg = (f"{len(dupes)} من {len(files)} موجودة في النظام بالفعل")
            if committed:
                msg += NL + f"({len(committed)} منها مُودَعة كموظفين — لن تُحذف)"
            msg += (NL + NL + "نعم = ارفعها مجددًا (سيُعاد قراءتها)"
                    + NL + "لا  = تخطَّها وارفع الجديد فقط"
                    + NL + "إلغاء = لا ترفع شيئًا")
            again = messagebox.askyesnocancel("ملفات مرفوعة مسبقًا", msg, parent=self.root)
            if again is None:
                self.msg_var.set("أُلغي"); return False
            if again:
                forget = [h for n, h in shas.items()
                          if h in known and known[h] not in ("done", "committed")]
                n = api.forget(list(set(forget)))
                self.msg_var.set(f"سيُعاد رفع {n} ملف")
            else:
                self.msg_var.set(f"سيُتخطّى {len(dupes)} ملف مرفوع مسبقًا")
            return True
        except Exception as e:
            self.msg_var.set(f"تعذّر فحص المكرّر: {e}")
            return True                      # never block the upload over a pre-flight check

    def _link(self, on):
        on = bool(on and getattr(self.cfg, "app_url", ""))
        """Turn the result line into a link when there IS somewhere to go.

        A run that ends with files waiting for review should hand the user straight to them —
        the whole point of tying the uploader to «الوارد» is that finishing here means starting
        there. When nothing needs attention the line stays plain text, because a link that leads
        nowhere is worse than no link."""
        if on:
            self.msg_lbl.config(fg=COPPER, cursor="hand2")
            self.msg_lbl.bind("<Button-1>", lambda _e: self._open_inbox())
        else:
            self.msg_lbl.config(fg=MUTED, cursor="")
            self.msg_lbl.unbind("<Button-1>")

    def _open_inbox(self):
        import webbrowser
        if getattr(self.cfg, "app_url", ""):
            webbrowser.open(self.cfg.app_url)

    def _run(self):
        from pump import AuthError
        try:
            self.pump.run()
        except AuthError as e:
            self.cfg.clear_password()      # never keep a credential the server refused
            self.events.put({"kind": "auth", "why": str(e)})
        except Exception as e:
            self.events.put({"kind": "error", "why": f"{type(e).__name__}: {e}"})

    def stop(self):
        if self.pump:
            self.pump.stop.set()
            self.msg_var.set("جارٍ الإيقاف… الملفات قيد الرفع تعود إلى المجلد")

    SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧"

    def _spin(self):
        """Animate only while the worker is actually reading — a spinner that never stops is
        noise, and one that spins when nothing is happening is a lie."""
        if not self.reading:
            return
        self._spin_i = (self._spin_i + 1) % len(self.SPIN)
        self.read_var.set(f"{self.SPIN[self._spin_i]}  {self._read_txt}")
        self.root.after(90, self._spin)

    def _idle(self):
        """Back to the resting state, ready for the NEXT batch.

        The finished run's list STAYS — it is the receipt, and the whole point of showing which
        file went where. What goes is anything that implies work is still happening: the spinner,
        the "you can close the browser" note, the disabled buttons."""
        self.running = False
        self.reading = False
        self.read_lbl.grid_remove()
        self.read_var.set("")
        self.safe.grid_remove()
        self.go.config(state="normal"); self.add_btn.config(state="normal")
        self.fold_btn.config(state="normal")
        self.stop_btn.config(state="disabled", fg=LINE)
        self.refresh_ready()
        self.render_list()

    # ── the event pump (worker threads never touch Tk) ──────────────────────
    def drain(self):
        try:
            while True:
                e = self.events.get_nowait(); k = e.get("kind")
                if k == "start":
                    self.safe.grid()
                    self.msg_var.set(f"دفعة {e['batch']} — {e['total']} ملف")
                elif k == "begin":
                    self.set_row(e["name"], state="up"); self.render_list()
                elif k in ("ok", "skip", "fail"):
                    self.set_row(e["name"],
                                 state={"ok": "sent", "skip": "skip", "fail": "failed"}[k],
                                 hash=e.get("hash"), why=e.get("why", ""))
                    self.render_list()
                elif k == "reading":
                    total = e.get("total") or 0
                    left  = e.get("in_flight") or 0
                    self.apply_rows(e.get("rows"))
                    self._read_txt = (f"يقرأ الملفات… {total - left}/{total}"
                                      if left else "اكتملت القراءة")
                    if not self.reading:
                        self.reading = True
                        self.read_lbl.grid()
                        self._spin()
                    self.read_var.set(f"{self.SPIN[self._spin_i]}  {self._read_txt}")
                    if not left:
                        self.reading = False
                elif k == "empty":
                    self._link(False)
                    self.msg_var.set("الطابور فارغ — أضف ملفات ثم ابدأ"); self._idle()
                elif k == "finish":
                    self._idle()
                    st = e.get("state")
                    if st:
                        msg = (f"{st['total']} = أُودِعت {st['committed']}"
                               f" + للمراجعة {st['review']} + مرفوض {st['refused']}")
                        if st.get("in_flight"):
                            msg += f" · ما زال {st['in_flight']} قيد المعالجة"
                        elif st.get("review") or st.get("refused"):
                            msg += (" — اضغط هنا لفتح «الوارد» ↗"
                                    if getattr(self.cfg, "app_url", "") else
                                    " — راجِعها في «الوارد» بالموقع")
                            self._link(True)
                        elif st.get("committed"):
                            msg += " ✓"
                        self.msg_var.set(msg)
                    else:
                        self.msg_var.set(f"توقف — أُرسل {e.get('done', 0)}"
                                         f" · فشل {e.get('failed', 0)}")
                elif k == "error":
                    self._link(False)
                    self.msg_var.set(e.get("why", "خطأ")); self._idle()
        except queue.Empty:
            pass
        self.root.after(120, self.drain)


if __name__ == "__main__":
    _k = enable_dpi()                     # BEFORE Tk(), or Windows stretches the window
    root = tk.Tk(); App(root, _k); root.mainloop()
