# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · the window
===============================
Tkinter on purpose: it ships with Python, so there is nothing to install and no PyInstaller .exe
to be quarantined by antivirus.

Design notes, because the first version was criticised fairly:
  • Colours are the app's OWN brand tokens (read from assets/app.css), not approximations, so the
    tool looks like part of the system rather than a utility bolted on.
  • Everything lives in a CENTRED column with a maximum width. Tk stretches widgets to fill by
    default, which is why maximising the first version looked broken — a full-screen window now
    just gets more margin, exactly as the web app does.
  • Type has a real hierarchy (title / label / data), and numbers are set in a monospace face so
    a changing count does not make the line jitter.
  • ADD FILES is a first-class button. Requiring the user to go to Explorer, copy files in, come
    back and press start is a worse flow than the drop zone it is replacing.
"""
from __future__ import annotations
import pathlib, queue, shutil, sys, threading, time, tkinter as tk
from tkinter import filedialog, ttk

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pump import Config, Pump                      # noqa: E402

# the app's own tokens (assets/app.css :root)
BG      = "#1b2930"
PANEL   = "#21403b"
CARD    = "#2c3533"
INK     = "#f7f4ec"
INK2    = "#dcd8cc"
MUTED   = "#a7ada6"
LINE    = "#3c4f4d"
COPPER  = "#dba875"
TEAL    = "#6fc0c0"
RED     = "#ff4d59"

UI   = "Segoe UI"
MONO = "Consolas"
NL   = chr(10)          # newlines are built explicitly rather than escaped
MAXW = 620          # the content column never grows past this; maximising adds margin, not stretch


def enable_dpi():
    """Declare DPI awareness BEFORE Tk starts, or Windows renders the window at 96 DPI and
    bitmap-STRETCHES it to the display's scale. That stretch is what makes the text look blurry
    and the whole thing cheap — this screen runs at 120 DPI (1.25x), so every glyph was being
    resampled. Declared, Tk draws at native resolution and the type is sharp.

    Must run before the first tk.Tk(); called from both entry points. Returns the scale factor so
    pixel geometry can be scaled too — point-sized fonts Tk handles itself."""
    scale = 1.0
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)      # per-monitor v2 (Win 8.1+)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()           # fallback (Vista+)
        u = ctypes.windll.user32
        dc = u.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(dc, 88)         # LOGPIXELSX
        u.ReleaseDC(0, dc)
        scale = max(1.0, dpi / 96.0)
    except Exception:
        pass                                                    # not Windows, or no shcore
    return scale


def _btn(parent, text, cmd, *, kind="ghost", font=None, padx=16, pady=8):
    """A flat button with a HOVER state.

    Tk buttons default to a raised 3-D border and no hover feedback, which is most of why the
    window read as dated. Flat + a colour shift on hover is what the web app does, and it is the
    single biggest change in making this feel like the same product.

      filled → the one primary action     ghost → secondary     quiet → tertiary/text
    """
    look = {"filled": dict(bg=COPPER, fg="#1a1206", hbg="#e9bd8f", hfg="#1a1206"),
            "ghost":  dict(bg=BG,     fg=COPPER,    hbg=CARD,      hfg=INK),
            "quiet":  dict(bg=BG,     fg=MUTED,     hbg=BG,        hfg=COPPER)}[kind]
    b = tk.Button(parent, text=text, command=cmd, bd=0, relief="flat",
                  highlightthickness=0, activebackground=look["hbg"],
                  activeforeground=look["hfg"], bg=look["bg"], fg=look["fg"],
                  font=font or (UI, 10), padx=padx, pady=pady, cursor="hand2")
    def on(_):  b.config(bg=look["hbg"], fg=look["hfg"])
    def off(_):
        if str(b["state"]) != "disabled": b.config(bg=look["bg"], fg=look["fg"])
    b.bind("<Enter>", on); b.bind("<Leave>", off)
    b._look = look
    return b


class App:
    def __init__(self, root: tk.Tk, scale: float = 1.0):
        self.root = root
        self.k = scale                       # pixel geometry must follow the display scale
        px = lambda n: int(n * scale)
        self.px = px
        root.title("ICCMC · أداة الرفع")
        root.configure(bg=BG)
        root.geometry(f"{px(700)}x{px(560)}")
        root.minsize(px(560), px(500))

        try:
            self.cfg, self.err = Config(HERE / "pump.ini"), None
        except SystemExit as e:
            self.cfg, self.err = None, str(e)

        self.pump = None
        self.events = queue.Queue()
        self.t0 = None
        # ONE explicit flag for "a run is in progress". This used to be inferred from the progress
        # bar (pump exists AND value < maximum), which silently lied after a failed sign-in: the
        # pump object lingered, stop was never set, and the bar sat at 0/100 because the 'start'
        # event never fired — so Start believed a run was active and did NOTHING when pressed.
        # State that matters is never read back out of a widget.
        self.running = False
        self.reading = False          # phase 2: the worker is reading what we sent
        self._read_txt = ""
        self._style()

        # ── centred column ─────────────────────────────────────────────────
        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True)
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_columnconfigure(1, minsize=0)
        outer.grid_columnconfigure(2, weight=1)
        outer.grid_rowconfigure(0, weight=1)
        col = tk.Frame(outer, bg=BG)
        col.grid(row=0, column=1, sticky="n", pady=26)
        col.grid_columnconfigure(0, minsize=px(MAXW))

        # ── header ─────────────────────────────────────────────────────────
        head = tk.Frame(col, bg=BG); head.grid(row=0, column=0, sticky="ew", padx=4)
        tk.Label(head, text="أداة الرفع", bg=BG, fg=INK,
                 font=(UI, 21, "bold")).pack(anchor="e")
        tk.Label(head, text="ارفع دفعة كبيرة دون المتصفح — الطابور مجلد على قرصك",
                 bg=BG, fg=MUTED, font=(UI, 10)).pack(anchor="e", pady=(2, 0))
        tk.Frame(col, bg=LINE, height=1).grid(row=1, column=0, sticky="ew", pady=(16, 18), padx=4)

        # ── the folder card ────────────────────────────────────────────────
        card = tk.Frame(col, bg=CARD, highlightthickness=0)
        card.grid(row=2, column=0, sticky="ew", padx=4)
        card.grid_columnconfigure(1, weight=1)
        inner = tk.Frame(card, bg=CARD, padx=16, pady=14)
        inner.pack(fill="x")
        inner.grid_columnconfigure(1, weight=1)

        chg = _btn(inner, "تغيير", self.pick, kind="ghost", font=(UI, 9),
                   padx=px(13), pady=px(5))
        chg.configure(bg=CARD); chg._look.update(bg=CARD, hbg=PANEL)
        chg.grid(row=0, column=0, rowspan=2, padx=(0, px(14)))
        self.folder_var = tk.StringVar(value=str(self.cfg.folder) if self.cfg else "—")
        tk.Label(inner, textvariable=self.folder_var, bg=CARD, fg=INK2, anchor="e",
                 font=(MONO, 9)).grid(row=0, column=1, sticky="ew")
        self.ready_var = tk.StringVar(value="")   # live count, refreshed by the folder watcher
        tk.Label(inner, textvariable=self.ready_var, bg=CARD, fg=TEAL, anchor="e",
                 font=(UI, 9)).grid(row=1, column=1, sticky="ew", pady=(3, 0))

        # ── add files · open folder ────────────────────────────────────────
        acts = tk.Frame(col, bg=BG); acts.grid(row=3, column=0, sticky="ew", pady=(12, 0), padx=4)
        self.add_btn = _btn(acts, "＋   أضف ملفات", self.add_files, kind="ghost",
                            font=(UI, 10, "bold"), padx=px(22), pady=px(10))
        self.add_btn.pack(side="right")
        _btn(acts, "افتح المجلد", self.open_folder, kind="quiet",
             font=(UI, 9), padx=0, pady=px(10)).pack(side="left")
        self.again_btn = _btn(acts, "↺  أعِد إرسال المُرسَل", self.resend, kind="quiet",
                              font=(UI, 9), padx=px(12), pady=px(10))
        self.again_btn.pack(side="left", padx=(px(14), 0))

        # ── progress ───────────────────────────────────────────────────────
        prog = tk.Frame(col, bg=BG); prog.grid(row=4, column=0, sticky="ew", pady=(24, 0), padx=4)
        self.prog = prog
        self.count_var = tk.StringVar(value="—")
        tk.Label(prog, textvariable=self.count_var, bg=BG, fg=INK,
                 font=(MONO, 15, "bold")).pack(anchor="e")
        self.bar = ttk.Progressbar(prog, style="I.Horizontal.TProgressbar", maximum=100)
        self.bar.pack(fill="x", pady=(8, 6))
        self.rate_var = tk.StringVar(value="")
        tk.Label(prog, textvariable=self.rate_var, bg=BG, fg=MUTED,
                 font=(MONO, 9)).pack(anchor="e")
        # phase 2 — the worker reading. Uploading is the fast half; this is where the time goes,
        # and saying "done" when the bytes left was a lie the user could see through.
        self.read_var = tk.StringVar(value="")
        self.read_lbl = tk.Label(prog, textvariable=self.read_var, bg=BG, fg=TEAL,
                                 font=(UI, 10, "bold"))
        self.read_lbl.pack(anchor="e", pady=(10, 0))
        self.read_lbl.pack_forget()
        self._spin_i = 0
        prog.grid_remove()                      # appears only once there is progress to show

        self.safe = tk.Label(col, text="✓   يمكنك إغلاق المتصفح — الرفع مستمر",
                             bg=BG, fg=TEAL, font=(UI, 10, "bold"))
        self.safe.grid(row=5, column=0, sticky="e", pady=(18, 0), padx=4)
        self.safe.grid_remove()

        self.msg_var = tk.StringVar(
            value=self.err or "أضف ملفات ثم اضغط «ابدأ الرفع»")
        tk.Label(col, textvariable=self.msg_var, bg=BG, fg=(RED if self.err else MUTED),
                 wraplength=px(MAXW) - 20, justify="right", font=(UI, 9)
                 ).grid(row=6, column=0, sticky="e", pady=(14, 0), padx=4)

        # ── footer ─────────────────────────────────────────────────────────
        foot = tk.Frame(col, bg=BG); foot.grid(row=7, column=0, sticky="ew", pady=(26, 0), padx=4)
        self.go = _btn(foot, "ابدأ الرفع", self.start, kind="filled",
                       font=(UI, 12, "bold"), padx=px(32), pady=px(12))
        self.go.pack(side="right")
        self.stop_btn = _btn(foot, "إيقاف", self.stop, kind="ghost",
                             font=(UI, 10), padx=px(20), pady=px(12))
        self.stop_btn.config(state="disabled", fg=LINE)      # visibly inert until a run starts
        self.stop_btn.pack(side="right", padx=(0, px(10)))

        if self.err:
            self.go.config(state="disabled"); self.add_btn.config(state="disabled")
        else:
            self.refresh_ready()
            self.watch_folder()          # the folder IS the queue — notice it changing
        self.root.after(120, self.drain)

    # ── styling ─────────────────────────────────────────────────────────────
    def _style(self):
        s = ttk.Style()
        try: s.theme_use("clam")            # the only built-in theme that honours custom colours
        except Exception: pass
        s.configure("I.Horizontal.TProgressbar", troughcolor=CARD, background=COPPER,
                    bordercolor=CARD, lightcolor=COPPER, darkcolor=COPPER,
                    thickness=int(10 * self.k))

    # ── state ───────────────────────────────────────────────────────────────
    def watch_folder(self):
        """Re-count every 1.5s while idle.

        You can put files in two ways — «＋ أضف ملفات», or by copying them into the folder in
        Explorer (which «افتح المجلد» opens for exactly that). The second way left the window
        showing a stale count until you clicked something, which makes the tool look broken when
        it is simply not looking. Cheap: one directory listing, and skipped entirely while a run
        is in progress, since the pump is moving those files itself."""
        try:
            if not self.running:
                self.refresh_ready()
        except Exception:
            pass
        self.root.after(1500, self.watch_folder)

    def refresh_ready(self):
        """How many files are actually sitting in the folder, waiting."""
        if not self.cfg: return 0
        try:
            self.cfg.folder.mkdir(parents=True, exist_ok=True)
            n = sum(1 for p in self.cfg.folder.iterdir()
                    if p.is_file() and not p.name.startswith("."))
        except Exception:
            n = 0
        self.ready_var.set(f"{n} ملف جاهز للرفع" if n else
                           "المجلد فارغ — اضغط «＋ أضف ملفات» أو انسخ ملفاتك إليه")
        # never re-enable Start mid-run; _idle() owns that when the run ends
        if not self.running:
            self.go.config(state=("normal" if n else "disabled"))
        return n

    # ── actions ─────────────────────────────────────────────────────────────
    def add_files(self):
        """Pick files from anywhere and copy them into the folder.

        Without this the flow was: leave the app, find the files in Explorer, copy them in, come
        back, press start — worse than the browser drop zone it replaces. Copying (not moving)
        is deliberate: the tool must never remove a file from wherever the user keeps it."""
        paths = filedialog.askopenfilenames(
            title="اختر الملفات",
            filetypes=[("كل الملفات المدعومة", "*.pdf *.jpg *.jpeg *.png *.webp *.xlsx *.docx"),
                       ("الكل", "*.*")])
        if not paths: return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        added = clash = 0
        for src in paths:
            src = pathlib.Path(src)
            dst = self.cfg.folder / src.name
            if dst.exists():                      # never silently overwrite a queued file
                stem, suf, i = dst.stem, dst.suffix, 2
                while dst.exists():
                    dst = self.cfg.folder / f"{stem} ({i}){suf}"; i += 1
                clash += 1
            try:
                shutil.copy2(src, dst); added += 1
            except Exception as e:
                self.msg_var.set(f"تعذّر نسخ {src.name}: {e}")
        n = self.refresh_ready()
        self.msg_var.set(f"أُضيف {added} ملف — المجموع {n}"
                         + (f" · {clash} بالاسم نفسه أُعيدت تسميتها" if clash else ""))

    def resend(self):
        """Move everything in _done back into the folder, so it can be sent again.

        A file the uploader has handled lives in _done, which is what makes a restart safe — but
        it also meant there was NO WAY to re-send. Deleting a card in the app and re-running the
        uploader did nothing, because the folder was empty and the tool had no reason to say so.
        The queue is a folder, so re-queueing has to be a folder move.

        The system still refuses genuine duplicates by content hash — this only gives the file
        another chance to be OFFERED. If its row was deleted in the app it will be read afresh;
        if not, it is skipped as already known, which is the correct answer either way."""
        done = self.cfg.folder / "_done"
        if not done.exists():
            self.msg_var.set("لا شيء أُرسل بعد"); return
        files = [f for f in done.iterdir() if f.is_file()]
        if not files:
            self.msg_var.set("لا شيء في «_done» لإعادة إرساله"); return
        moved = 0
        for f in files:
            dst = self.cfg.folder / f.name
            if dst.exists():
                stem, suf, i = dst.stem, dst.suffix, 2
                while dst.exists():
                    dst = self.cfg.folder / f"{stem} ({i}){suf}"; i += 1
            try:
                shutil.move(str(f), str(dst)); moved += 1
            except Exception as e:
                self.msg_var.set(f"تعذّر نقل {f.name}: {e}"); break
        n = self.refresh_ready()
        self.msg_var.set(f"أُعيد {moved} ملف إلى الطابور — المجموع {n}. "
                         f"المكرّر فعليًا سيُتخطّى تلقائيًا.")

    def pick(self):
        d = filedialog.askdirectory(title="اختر مجلد الرفع")
        if d:
            self.cfg.folder = pathlib.Path(d)
            self.folder_var.set(d)
            self.refresh_ready()

    def open_folder(self):
        if not self.cfg: return
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        import os; os.startfile(self.cfg.folder)                    # noqa: S606 (Windows)

    def start(self):
        if not self.cfg: return
        if self.running:
            return                                                   # already running
        if not self.refresh_ready():
            self.msg_var.set("المجلد فارغ — أضف ملفات أولًا"); return
        # Asked on the machine, stored in the gitignored pump.ini — the password never travels
        # through a chat, a code edit or a diff. Asked once; later runs read the file.
        if not self.cfg.password:
            from tkinter import simpledialog
            pw = simpledialog.askstring("كلمة المرور",
                                        f"كلمة مرور {self.cfg.email}\n(تُحفظ في pump.ini على جهازك)",
                                        show="•", parent=self.root)
            if not pw:
                self.msg_var.set("لا يمكن الرفع بدون كلمة المرور"); return
            try: self.cfg.save_password(pw.strip())
            except Exception as e:
                self.msg_var.set(f"تعذّر حفظ كلمة المرور: {e}"); return
        if not self._ask_about_known():
            return
        self.pump = Pump(self.cfg, lambda **k: self.events.put(k))
        self.t0 = time.time()
        self.running = True
        self.go.config(state="disabled"); self.add_btn.config(state="disabled")
        self.stop_btn.config(state="normal"); self.msg_var.set("")
        threading.Thread(target=self._run, daemon=True).start()

    def _ask_about_known(self):
        """Before uploading, say plainly which files the system already has, and let the user choose.

        The uploader used to skip known content silently — so re-adding files looked like nothing
        happened, and the tool felt disconnected from «الوارد». Now it tells you, and «ارفعها
        مجددًا» forgets their rows first, because the line dedups by hash and a re-drop is
        otherwise a no-op. A COMMITTED file is never forgotten — that is an employee record.
        """
        import hashlib
        from tkinter import messagebox
        try:
            files = [f for f in self.cfg.folder.iterdir()
                     if f.is_file() and not f.name.startswith(".")]
            if not files:
                return True
            shas = {}
            for f in files:
                h = hashlib.sha256(); 
                with f.open("rb") as fh:
                    for c in iter(lambda: fh.read(1 << 20), b""): h.update(c)
                shas[f.name] = h.hexdigest()
            api = __import__("pump").Api(self.cfg)
            known = api.known_hashes(list(set(shas.values())))
            if not known:
                return True
            dupes = {n: known[h] for n, h in shas.items() if h in known}
            committed = [n for n, st in dupes.items() if st in ("done", "committed")]
            msg = (f"{len(dupes)} من {len(files)} موجودة في النظام بالفعل")
            if committed:
                msg += NL + f"({len(committed)} منها مُودَعة كموظفين — لن تُحذف)"
            msg += (NL + NL + "نعم = ارفعها مجددًا (سيُعاد قراءتها)"
                    + NL + "لا  = تخطَّها وارفع الجديد فقط"
                    + NL + "إلغاء = لا ترفع شيئًا")
            again = messagebox.askyesnocancel("ملفات مرفوعة مسبقًا", msg, parent=self.root)
            if again is None:
                self.msg_var.set("أُلغي"); return False
            if again:
                forget = [h for n, h in shas.items()
                          if h in known and known[h] not in ("done", "committed")]
                n = api.forget(list(set(forget)))
                self.msg_var.set(f"سيُعاد رفع {n} ملف")
            else:
                self.msg_var.set(f"سيُتخطّى {len(dupes)} ملف مرفوع مسبقًا")
            return True
        except Exception as e:
            self.msg_var.set(f"تعذّر فحص المكرّر: {e}")
            return True                      # never block the upload over a pre-flight check

    def _run(self):
        from pump import AuthError
        try:
            self.pump.run()
        except AuthError as e:
            self.cfg.clear_password()      # never keep a credential the server refused
            self.events.put({"kind": "auth", "why": str(e)})
        except Exception as e:
            self.events.put({"kind": "error", "why": f"{type(e).__name__}: {e}"})

    def stop(self):
        if self.pump:
            self.pump.stop.set()
            self.msg_var.set("جارٍ الإيقاف… الملفات قيد الرفع تعود إلى المجلد")

    SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧"

    def _spin(self):
        """Animate only while the worker is actually reading — a spinner that never stops is
        noise, and one that spins when nothing is happening is a lie."""
        if not self.reading:
            return
        self._spin_i = (self._spin_i + 1) % len(self.SPIN)
        self.read_var.set(f"{self.SPIN[self._spin_i]}  {self._read_txt}")
        self.root.after(90, self._spin)

    def _idle(self):
        self.running = False
        self.reading = False
        self.read_lbl.pack_forget()
        self.safe.grid_remove()
        self.go.config(state="normal"); self.add_btn.config(state="normal")
        self.stop_btn.config(state="disabled", fg=LINE)
        self.refresh_ready()

    # ── the event pump (worker threads never touch Tk) ──────────────────────
    def drain(self):
        try:
            while True:
                e = self.events.get_nowait(); k = e.get("kind")
                if k == "start":
                    self.bar["maximum"] = e["total"]; self.bar["value"] = 0
                    self.count_var.set(f"0 / {e['total']}"); self.rate_var.set("")
                    self.prog.grid(); self.safe.grid()
                    self.msg_var.set(f"دفعة {e['batch']}")
                elif k in ("ok", "skip", "fail"):
                    p = self.pump; n = p.done + p.failed
                    self.bar["value"] = n
                    self.count_var.set(f"{n} / {p.total}")
                    mins = max((time.time() - self.t0) / 60, 1e-6)
                    self.rate_var.set(f"{n/mins:.0f}/دقيقة · فشل {p.failed}"
                                      + (f" · معروف مسبقًا {p.skipped}" if p.skipped else ""))
                elif k == "reading":
                    total = e.get("total") or 0
                    left  = e.get("in_flight") or 0
                    read  = total - left
                    self._read_txt = (f"يقرأ الملفات… {read}/{total}"
                                      if left else f"اكتملت قراءة {total}")
                    if not self.reading:
                        self.reading = True
                        self.prog.grid()          # a 'reading' can arrive with no 'start' (all skipped)
                        self.read_lbl.pack(anchor="e", pady=(10, 0))
                        self._spin()
                    # paint NOW as well as on the next spinner tick, or the count lags a beat
                    # behind the truth — and the last update (0 left) would never be shown at all
                    self.read_var.set(f"{self.SPIN[self._spin_i]}  {self._read_txt}")
                    if not left:
                        self.reading = False      # stop the animation; the text stays
                    self.msg_var.set(
                        f"أُودِعت {e.get('committed',0)} · قيد المراجعة {e.get('review',0)}"
                        f" · مرفوض {e.get('refused',0)}")
                elif k == "empty":
                    self.msg_var.set("المجلد فارغ — أضف ملفات ثم ابدأ"); self._idle()
                elif k == "finish":
                    self._idle()
                    st = e.get("state")
                    if st:
                        # the conservation law, stated by the tool that did the pumping
                        msg = (f"{st['total']} = أُودِعت {st['committed']}"
                               f" + قيد المراجعة {st['review']} + مرفوض {st['refused']}")
                        if st.get("in_flight"):
                            msg += f" · ما زال {st['in_flight']} قيد المعالجة"
                        elif st.get("committed"):
                            msg += " — افتح «الوارد» في الموقع"
                    else:
                        msg = f"اكتمل {e['done']} · فشل {e['failed']}"
                    if e["failed"]:
                        msg += " · انظر مجلد _failed، مع سبب لكل ملف"
                    self.msg_var.set(msg)
                elif k == "auth":
                    # the password was refused → it has already been forgotten, so simply
                    # pressing Start asks again. A wrong password must never be a dead end.
                    self._idle(); self.msg_var.set(e["why"] + " — اضغط «ابدأ الرفع» لإدخالها ثانيةً")
                elif k == "error":
                    self._idle(); self.msg_var.set(e["why"])
        except queue.Empty:
            pass
        self.root.after(120, self.drain)


if __name__ == "__main__":
    _k = enable_dpi()                     # BEFORE Tk(), or Windows stretches the window
    root = tk.Tk(); App(root, _k); root.mainloop()
