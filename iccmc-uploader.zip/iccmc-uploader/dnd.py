# -*- coding: utf-8 -*-
"""Drop files onto the window — native Windows, no extra install.

The uploader replaces a browser drop zone, so the first thing anyone tries is to drag files onto
it. Tk has no drag-and-drop of its own, and the usual answer (tkinterdnd2) is a pip install — which
would break the one promise this tool makes: download the folder, double-click, it runs. So we ask
Windows directly: `DragAcceptFiles` marks the window as a drop target, and Windows then posts
WM_DROPFILES with a handle we read the paths out of.

Reading the paths means replacing the window's message handler with our own, which is the risky
part — a bad handler takes Tk down with it. Three rules keep it safe:

  * every message we do not care about goes straight back to the original handler, untouched;
  * our own handling is wrapped, so an exception in the callback can never escape into Windows;
  * setup returns False instead of raising, so a machine where any of this fails simply gets the
    tool as it was before — «أضف ملفات» still works, nothing is broken.

The reference to the callback is kept alive deliberately: if Python collects it while Windows still
holds the pointer, the next message is a hard crash.
"""
import ctypes
from ctypes import wintypes

WM_DROPFILES = 0x0233
GWL_WNDPROC = -4

_alive = []          # keeps callbacks (and their trampolines) from being collected — see above


def enable(widget, on_files):
    """Let `widget`'s window accept dropped files; call on_files([paths]) for each drop.

    Returns True if drag-and-drop is now live, False if this platform/machine cannot do it.
    """
    try:
        user32, shell32 = ctypes.windll.user32, ctypes.windll.shell32
        hwnd = wintypes.HWND(widget.winfo_id())

        # Tk's real window is the toplevel; a child frame is not what Windows drops onto.
        root_hwnd = wintypes.HWND(user32.GetAncestor(hwnd, 2))     # GA_ROOT
        hwnd = root_hwnd if root_hwnd.value else hwnd

        shell32.DragAcceptFiles(hwnd, True)

        # LRESULT/LPARAM are POINTER-SIZED. Declaring them as c_long works by accident on 32-bit
        # and fails on every real machine: ctypes then guesses c_int for the pass-through call and
        # overflows on any message carrying a pointer, so Tk's own handler stops being reached.
        LRESULT = ctypes.c_ssize_t
        WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, ctypes.c_uint,
                                     wintypes.WPARAM, wintypes.LPARAM)
        user32.CallWindowProcW.restype = LRESULT
        user32.CallWindowProcW.argtypes = [ctypes.c_void_p, wintypes.HWND, ctypes.c_uint,
                                           wintypes.WPARAM, wintypes.LPARAM]
        # 64-bit needs the Ptr variants; 32-bit only has the plain ones.
        get_l = getattr(user32, "GetWindowLongPtrW", None) or user32.GetWindowLongW
        set_l = getattr(user32, "SetWindowLongPtrW", None) or user32.SetWindowLongW
        set_l.restype, get_l.restype = ctypes.c_void_p, ctypes.c_void_p
        set_l.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
        get_l.argtypes = [wintypes.HWND, ctypes.c_int]

        old = get_l(hwnd, GWL_WNDPROC)

        def handler(h, msg, wp, lp):
            if msg == WM_DROPFILES:
                try:
                    paths = _paths_from(shell32, wp)
                    shell32.DragFinish(wintypes.HWND(wp))
                    if paths:
                        on_files(paths)
                except Exception:
                    pass                       # a drop that fails must not kill the window
                return 0
            return user32.CallWindowProcW(ctypes.c_void_p(old), h, msg, wp, lp)

        cb = WNDPROC(handler)
        set_l(hwnd, GWL_WNDPROC, ctypes.cast(cb, ctypes.c_void_p))
        _alive.append((cb, old, hwnd))
        return True
    except Exception:
        return False


def _paths_from(shell32, hdrop):
    """Pull the dropped paths out of an HDROP."""
    h = wintypes.HWND(hdrop)
    n = shell32.DragQueryFileW(h, 0xFFFFFFFF, None, 0)     # 0xFFFFFFFF = "how many?"
    out = []
    for i in range(n):
        need = shell32.DragQueryFileW(h, i, None, 0) + 1
        buf = ctypes.create_unicode_buffer(need)
        shell32.DragQueryFileW(h, i, buf, need)
        if buf.value:
            out.append(buf.value)
    return out
