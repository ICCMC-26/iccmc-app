@echo off
cd /d "%~dp0"
python pump_gui.py
if errorlevel 1 pause
