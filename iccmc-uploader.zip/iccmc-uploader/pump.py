# -*- coding: utf-8 -*-
r"""
ICCMC — أداة الرفع · the folder uploader
========================================
The browser is the wrong place to hold hours of pending work. With 3000 files only ~12 are moving
and the rest are handles in a page's memory; refresh, and the browser revokes them. That is not a
bug we can fix — it is the browser refusing to let a page re-read your disk without you choosing
again. Google's own Cloud Console cancels an upload on refresh for exactly the same reason.

So the queue stops being memory in a page and becomes FILES IN A FOLDER, which survive refresh,
closing, logout, reboot and power cuts, because that is what a disk does. This is the same pattern
enterprise ingest has used for decades (Aspera hot folders, rclone-watch, the Dropbox client).

    pump\                 ← drop files here, from anywhere
      ├─ _uploading\      ← in flight right now
      ├─ _done\           ← landed; the OCR line has them
      └─ _failed\         ← with a .txt beside each saying why

What it does NOT change: the bucket, the worker, the OCR line, the review queue, the conservation
law. It stamps `declared_total` and writes the same `received` ledger row the browser writes, so a
folder batch settles with the same verdict. One premise, two doors.

Config lives in `pump.ini` beside this file (gitignored — it holds a password).
"""
from __future__ import annotations
import configparser, hashlib, json, mimetypes, pathlib, queue, random, shutil, sys, threading, time
import urllib.request, urllib.error

HERE = pathlib.Path(__file__).resolve().parent
BUCKET = "intake"
SUB = ("_uploading", "_done", "_failed")


# ── config ──────────────────────────────────────────────────────────────────
class Config:
    def __init__(self, path: pathlib.Path):
        cp = configparser.ConfigParser()
        if not path.exists():
            raise SystemExit(f"missing config: {path}\nCopy pump.example.ini to pump.ini and fill it in.")
        cp.read(path, encoding="utf-8")
        s = cp["supabase"]
        self.url = s["url"].rstrip("/")
        self.anon = s["anon_key"]
        self.email = s["email"]
        # Deliberately allowed to be blank. The tool asks for it on first run and writes it here
        # itself, so the password never has to travel through a chat, a code edit, or a diff.
        self.password = s.get("password", "").strip()
        # Where «الوارد» lives, so a finished run can hand the user straight to it. OPTIONAL and
        # blank by default: a link that goes nowhere is worse than no link, and the deployment URL
        # is not something this tool can know.
        self.app_url = s.get("app_url", "").strip()
        self._path = path
        # The [pump] section must be read HERE. These three had drifted into save_password(),
        # so folder/parallel/retries only existed if a password happened to be saved first —
        # a fresh run crashed with AttributeError before printing anything useful.
        p = cp["pump"] if cp.has_section("pump") else {}
        self.folder = pathlib.Path(str(p.get("folder", HERE / "pump"))).expanduser()
        self.parallel = int(p.get("parallel", 6))
        self.retries = int(p.get("retries", 6))

    def clear_password(self):
        """Forget a password that the server rejected, so the tool can ask again.

        Without this a single typo was permanent: the wrong value was written to pump.ini, and
        because `password` was then non-empty nothing ever prompted for it again — the user was
        stuck looking at 'HTTP Error 400' with no way back. A credential that fails must not be
        kept."""
        self.password = ""
        try:
            cp = configparser.ConfigParser(); cp.read(self._path, encoding="utf-8")
            cp["supabase"]["password"] = ""
            with self._path.open("w", encoding="utf-8") as f: cp.write(f)
        except Exception:
            pass

    def save_password(self, pw: str):
        """Store the password back into pump.ini (which is gitignored)."""
        cp = configparser.ConfigParser()
        cp.read(self._path, encoding="utf-8")
        cp["supabase"]["password"] = pw
        with self._path.open("w", encoding="utf-8") as f:
            cp.write(f)
        self.password = pw


# ── the Supabase side ───────────────────────────────────────────────────────
class AlreadyQueued(Exception):
    """This exact content already has a placeholder row. Not a failure — the file is accounted
    for, so the caller files it as done rather than retrying."""


class AuthError(Exception):
    """Sign-in was refused. Distinct from any other failure because it is the one the user can
    fix immediately, by retyping the password."""


class Api:
    """Only what the uploader needs: sign in, upload an object, write a ledger row, stamp a batch."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.token = None
        self._lock = threading.Lock()

    def _req(self, method, url, *, body=None, headers=None, timeout=120):
        data = None
        h = {"apikey": self.cfg.anon}
        if headers:
            h.update(headers)
        if body is not None and not isinstance(body, (bytes, bytearray)):
            data = json.dumps(body).encode()
            h["Content-Type"] = "application/json"
        elif body is not None:
            data = body
        r = urllib.request.Request(url, data=data, headers=h, method=method)
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            raw = resp.read()
            return resp.status, (json.loads(raw) if raw and resp.headers.get(
                "content-type", "").startswith("application/json") else raw)

    def sign_in(self):
        try:
            st, js = self._req("POST", f"{self.cfg.url}/auth/v1/token?grant_type=password",
                               body={"email": self.cfg.email, "password": self.cfg.password})
        except urllib.error.HTTPError as e:
            # Supabase answers a bad email/password with 400. Translate it, and flag it as an
            # AUTH failure so the caller knows to forget the password and ask again rather than
            # leaving the user staring at a status code.
            if e.code in (400, 401):
                raise AuthError("كلمة المرور أو البريد غير صحيح") from None
            raise
        except urllib.error.URLError as e:
            raise AuthError(f"تعذّر الوصول إلى الخادم — تحقّق من الاتصال ({e.reason})") from None
        self.token = js["access_token"]
        return js.get("user", {}).get("email", self.cfg.email)

    def _auth(self):
        # Refresh is deliberately crude — a fresh sign-in. The run is minutes-to-hours, not days,
        # and a re-login is cheaper to reason about than token-refresh bookkeeping.
        with self._lock:
            if not self.token:
                self.sign_in()
            return {"Authorization": f"Bearer {self.token}"}

    def relogin(self):
        with self._lock:
            self.token = None
        self._auth()

    def stamp_batch(self, batch_id, n, who):
        try:
            self._req("POST", f"{self.cfg.url}/rest/v1/intake_batches",
                      body={"batch_id": batch_id, "declared_total": n, "declared_by": who},
                      headers={**self._auth(), "Prefer": "return=minimal"})
        except Exception:
            pass          # no verdict for this batch; the upload is unaffected

    def batch_rows(self, batch_id):
        """Every file in the batch with the bucket it ended up in.

        batch_state answers "how many"; this answers "which one". A list that can only show totals
        forces the user to go and find out elsewhere what happened to a particular file — which is
        exactly the part that felt untrustworthy.
        """
        code, body = self._req(
            "GET", f"{self.cfg.url}/rest/v1/v_intake_ledger?batch_id=eq.{batch_id}"
                   "&select=image_hash,bucket,doc_type,fail_reason",
            headers=self._auth())
        if code == 401:
            self.relogin()
            code, body = self._req(
                "GET", f"{self.cfg.url}/rest/v1/v_intake_ledger?batch_id=eq.{batch_id}"
                       "&select=image_hash,bucket,doc_type,fail_reason",
                headers=self._auth())
        if code >= 300:
            raise RuntimeError(f"ledger {code}: {body[:120]}")
        return json.loads(body or "[]")

    def batch_state(self, batch_id):
        """Where the batch stands RIGHT NOW, straight from the ledger view the app reads.

        Uploading is the least interesting half. Saying "done" the moment the bytes leave is a
        lie the user can see through — the worker still has to read every file, which is where
        the time actually goes. Following the batch to its outcome is also what lets this tool
        state the conservation law itself: pumped = committed + review + refused."""
        st, js = self._req("GET",
                           f"{self.cfg.url}/rest/v1/v_intake_batches?batch_id=eq.{batch_id}"
                           "&select=total,committed,review,refused,in_flight,settled",
                           headers=self._auth())
        return (js[0] if js else None)

    def known_hashes(self, hashes):
        """Which of these contents does the system already have a row for? → {sha: status}

        Silently skipping a file the user deliberately re-added is the wrong answer: it looks
        like nothing happened. Asked up front, the user can decide — which is also what ties the
        uploader to «الوارد» instead of leaving them feeling like two systems."""
        out = {}
        for i in range(0, len(hashes), 40):              # bounded URL, same rule as the app
            chunk = ",".join(hashes[i:i + 40])
            st, js = self._req(
                "GET", f"{self.cfg.url}/rest/v1/scan_jobs?image_hash=in.({chunk})"
                       "&select=image_hash,status", headers=self._auth())
            for r in (js or []):
                out[r["image_hash"]] = r["status"]
        return out

    def forget(self, hashes):
        """Delete the rows for these contents so they can be read afresh — NEVER a committed one.

        The line dedups by content hash, so a re-drop of a known file is a silent no-op until its
        row is gone. That is exactly what made a re-pump 'not land'."""
        n = 0
        for h in hashes:
            try:
                self._req("DELETE",
                          f"{self.cfg.url}/rest/v1/scan_jobs?image_hash=eq.{h}"
                          "&status=not.in.(done,committed)",
                          headers={**self._auth(), "Prefer": "return=minimal"})
                n += 1
            except Exception:
                pass
        return n

    def already_there(self, sha):
        st, js = self._req("GET",
                           f"{self.cfg.url}/rest/v1/scan_jobs?image_hash=eq.{sha}&select=job_id&limit=1",
                           headers=self._auth())
        return bool(js)

    def ledger_row(self, batch_id, sha, name, key):
        """One row per file, written BEFORE the object exists — so a file can never be in the
        system without being countable. Same contract as the browser's ikLedgerRow.

        A 409 means a partial unique index rejected a second placeholder for this content: another
        thread got there first. That is the ATOMIC form of the duplicate check — asking "does a row
        exist?" and then inserting is a race, and with 6 threads on identical files it produced 9
        rows in one second, of which the worker could only ever advance one."""
        try:
            self._req("POST", f"{self.cfg.url}/rest/v1/scan_jobs",
                      body={"batch_id": batch_id, "source": "pump", "status": "received",
                            "doc_type": "unknown", "image_hash": sha, "image_path": key,
                            "fields": {"_original_filename": name}},
                      headers={**self._auth(), "Prefer": "return=minimal"})
        except urllib.error.HTTPError as e:
            if e.code == 409:
                raise AlreadyQueued(sha) from None
            raise

    def upload(self, key, blob, content_type):
        self._req("POST", f"{self.cfg.url}/storage/v1/object/{BUCKET}/{key}", body=blob,
                  headers={**self._auth(), "Content-Type": content_type, "x-upsert": "true"},
                  timeout=600)


# ── the pump ────────────────────────────────────────────────────────────────
def sha256(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def storage_key(job_no: int, name: str) -> str:
    """Mirror the browser's naming so the worker's filename rules (the `packet-` marker, the
    istimara/taahud type hints) behave identically whichever door a file came through."""
    # ASCII-only, deliberately. The browser sanitises with JS /[^\w.\-]+/ and JS \w is ASCII, so
    # Arabic is stripped there. Python's str.isalnum() says True for Arabic, which would produce a
    # DIFFERENT object name for the same file depending on which door it came through — and the
    # worker reads type hints out of that name. Match the browser exactly.
    safe = "".join(c if (c.isascii() and (c.isalnum() or c in "._-")) else "_" for c in name)
    low = name.lower()
    lt = "istimara-" if ("استمارة" in name or "istimara" in low) else (
         "taahud-" if ("تعهد" in name or "taahud" in low) else "")
    return f"{int(time.time()*1000):x}-{job_no}-{lt}{safe}"


class Pump:
    def __init__(self, cfg: Config, on_event=None):
        self.cfg, self.api = cfg, Api(cfg)
        self.on_event = on_event or (lambda **k: None)
        self.stop = threading.Event()
        self.done = self.failed = self.skipped = 0
        self.total = 0
        self._n = 0
        self._lock = threading.Lock()

    def _dirs(self):
        for s in SUB:
            (self.cfg.folder / s).mkdir(parents=True, exist_ok=True)

    def _pending(self):
        self.cfg.folder.mkdir(parents=True, exist_ok=True)
        self._dirs()
        return sorted(p for p in self.cfg.folder.iterdir()
                      if p.is_file() and not p.name.startswith("."))

    def _one(self, p: pathlib.Path, batch_id: str):
        """Upload one file. Anything that fails after `retries` lands in _failed WITH A REASON —
        never silently, and never retried forever."""
        moving = self.cfg.folder / "_uploading" / p.name
        try:
            shutil.move(str(p), str(moving))       # claim it: visible progress, and restart-safe
        except Exception:
            return
        self.on_event(kind="begin", name=p.name)   # this file is on the wire NOW
        last = ""
        for attempt in range(self.cfg.retries):
            if self.stop.is_set():
                shutil.move(str(moving), str(self.cfg.folder / p.name))   # put it back untouched
                return
            try:
                sha = sha256(moving)
                if self.api.already_there(sha):     # same bytes already known → don't double-count
                    shutil.move(str(moving), str(self.cfg.folder / "_done" / p.name))
                    with self._lock:
                        self.skipped += 1; self.done += 1
                    self.on_event(kind="skip", name=p.name, hash=sha)
                    return
                with self._lock:
                    self._n += 1; n = self._n
                key = storage_key(n, p.name)
                ct = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
                try:
                    self.api.ledger_row(batch_id, sha, p.name, key)   # countable BEFORE it exists
                except AlreadyQueued:
                    # another thread queued this exact content a moment ago. Not an error and not
                    # worth retrying — one placeholder is all the system needs.
                    shutil.move(str(moving), str(self.cfg.folder / "_done" / p.name))
                    with self._lock:
                        self.skipped += 1; self.done += 1
                    self.on_event(kind="skip", name=p.name)
                    return
                self.api.upload(key, moving.read_bytes(), ct)
                shutil.move(str(moving), str(self.cfg.folder / "_done" / p.name))
                with self._lock:
                    self.done += 1
                self.on_event(kind="ok", name=p.name, hash=sha)
                return
            except urllib.error.HTTPError as e:
                last = f"HTTP {e.code}: {e.read()[:200].decode('utf-8','replace')}"
                if e.code in (401, 403):
                    self.api.relogin()             # a long run outlives its token
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
            # An internet cut is the expected case, not an error: back off and keep waiting.
            time.sleep(min(30, (2 ** attempt) + random.random()))
        dest = self.cfg.folder / "_failed" / p.name
        shutil.move(str(moving), str(dest))
        dest.with_suffix(dest.suffix + ".txt").write_text(
            f"{p.name}\nfailed after {self.cfg.retries} attempts\n{last}\n", encoding="utf-8")
        with self._lock:
            self.failed += 1
        self.on_event(kind="fail", name=p.name, why=last)

    def run(self):
        who = self.api.sign_in()
        files = self._pending()
        self.total = len(files)
        if not self.total:
            self.on_event(kind="empty"); return
        batch_id = f"P{int(time.time()):x}-{random.randrange(16**4):04x}"
        self.api.stamp_batch(batch_id, self.total, who)     # declared_total → the law can be checked
        self.on_event(kind="start", total=self.total, batch=batch_id, who=who)

        q = queue.Queue()
        for f in files:
            q.put(f)

        def worker():
            while not self.stop.is_set():
                try:
                    f = q.get_nowait()
                except queue.Empty:
                    return
                try:
                    self._one(f, batch_id)
                finally:
                    q.task_done()

        threads = [threading.Thread(target=worker, daemon=True) for _ in range(self.cfg.parallel)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        if self.stop.is_set() or not self.done:
            self.on_event(kind="finish", done=self.done, failed=self.failed,
                          skipped=self.skipped, batch=batch_id, state=None)
            return
        # ── phase 2 · the worker reads them ────────────────────────────────────────────────
        # Poll the ledger until nothing is in flight. Deliberately capped: a stuck file must not
        # hold the window forever — the reaper resolves those server-side, and the app shows them.
        deadline = time.time() + 60 * 30
        last, misses = None, 0
        while time.time() < deadline and not self.stop.is_set():
            try:
                st = self.api.batch_state(batch_id)
                misses = 0
            except Exception:
                st, misses = None, misses + 1
                # Watching is a courtesy, not the job — the files are already uploaded and the
                # worker proceeds regardless. If the ledger cannot be read a few times running,
                # stop watching and say so, instead of spinning to the deadline in silence.
                if misses >= 5:
                    break
            if st:
                last = st
                try:
                    rows = self.api.batch_rows(batch_id)
                except Exception:
                    rows = []            # totals still tell the truth if the detail call fails
                self.on_event(kind="reading", rows=rows, **st)
                if not st.get("in_flight"):
                    break
            time.sleep(3)
        self.on_event(kind="finish", done=self.done, failed=self.failed,
                      skipped=self.skipped, batch=batch_id, state=last)


# ── console entry point (the GUI imports Pump directly) ─────────────────────
def main():
    cfg = Config(HERE / "pump.ini")
    t0 = time.time()

    def ev(kind, **k):
        if kind == "start":
            print(f"  {k['total']} file(s) · batch {k['batch']} · as {k['who']}\n")
        elif kind in ("ok", "skip", "fail"):
            n = pump.done + pump.failed
            rate = n / max((time.time() - t0) / 60, 1e-6)
            tag = {"ok": "✓", "skip": "≡", "fail": "✕"}[kind]
            print(f"\r  {tag} {n}/{pump.total} · {rate:5.1f}/min · failed {pump.failed}   ", end="")
        elif kind == "empty":
            print("  the folder is empty — nothing to upload")
        elif kind == "finish":
            print(f"\n\n  done {k['done']}  ·  failed {k['failed']}  ·  already known {k['skipped']}")
            print(f"  batch {k['batch']}")
            if k["failed"]:
                print(f"  see {cfg.folder / '_failed'} — each has a .txt saying why")

    print(f"\n  ICCMC · أداة الرفع\n  folder: {cfg.folder}\n")
    # Ask for the password HERE, on the machine, and store it in the gitignored pump.ini.
    # It never travels through a chat, a code edit or a diff — nobody but the operator sees it.
    if not cfg.password:
        import getpass
        pw = getpass.getpass(f"  password for {cfg.email} (stored in pump.ini): ").strip()
        if not pw:
            raise SystemExit("  no password — nothing to do")
        cfg.save_password(pw)
        print("  saved to pump.ini\n")
    pump = Pump(cfg, ev)
    try:
        pump.run()
    except KeyboardInterrupt:
        pump.stop.set()
        print("\n  stopped — anything mid-flight was put back; run again to continue")


if __name__ == "__main__":
    main()
