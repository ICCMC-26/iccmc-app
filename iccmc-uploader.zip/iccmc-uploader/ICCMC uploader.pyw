# -*- coding: utf-8 -*-
"""
ICCMC — أداة الرفع · double-click this
======================================
A .pyw is run by pythonw.exe, so there is NO console window — just the app. This is the file to
pin to the taskbar.

The catch a .pyw normally has is that a startup crash is completely SILENT: the window simply
never appears and you are left with nothing to report. So everything here is wrapped, and any
failure is shown in a message box instead of vanishing. `pump.bat` stays in the folder as the
console version for when you want the full traceback.
"""
import pathlib
import sys
import traceback

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def _die(title, msg):
    """Never fail silently — a .pyw with no console owes the user an explanation."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk(); r.withdraw()
        messagebox.showerror(title, msg)
        r.destroy()
    except Exception:
        # even the message box failed (no display?) — leave a file so there is still a trace
        try:
            (HERE / "startup-error.txt").write_text(f"{title}\n\n{msg}\n", encoding="utf-8")
        except Exception:
            pass
    sys.exit(1)


def main():
    if sys.version_info < (3, 8):
        _die("Python قديم",
             f"هذه الأداة تحتاج Python 3.8 أو أحدث.\nالموجود: {sys.version.split()[0]}")
    try:
        import tkinter as tk
    except Exception as e:
        _die("tkinter غير متوفر",
             "تعذّر تحميل واجهة tkinter — أعِد تثبيت Python مع خيار «tcl/tk».\n\n" + str(e))
    try:
        from pump_gui import App
    except SystemExit as e:                     # Config raises this for a missing pump.ini
        _die("الإعداد ناقص", str(e))
    except Exception:
        _die("تعذّر بدء الأداة", traceback.format_exc())
    try:
        root = tk.Tk()
        App(root)
        root.mainloop()
    except Exception:
        _die("توقفت الأداة", traceback.format_exc())


if __name__ == "__main__":
    main()
