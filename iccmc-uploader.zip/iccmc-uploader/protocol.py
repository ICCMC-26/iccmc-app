# -*- coding: utf-8 -*-
"""Let the website open this tool — `iccmc-uploader://open`.

A web page cannot start a program on your computer. That is not a gap in our design, it is the
rule browsers are built on, and nothing legitimate gets around it. The one sanctioned route is a
URL PROTOCOL: a program tells Windows "links beginning iccmc-uploader: belong to me", and after
that a link on the page opens it exactly the way an https: link opens a browser.

Scope, deliberately kept small:
  • HKEY_CURRENT_USER only — this user, no administrator rights, no machine-wide change.
  • Written on startup and rewritten if the path changed, so moving the folder repairs itself.
  • unregister() removes it completely; the key is the only trace this tool leaves outside its
    own folder.

If registration fails the tool still works normally — the website's "open" link simply does
nothing, and the page says so rather than pretending.
"""
import pathlib
import sys

KEY = r"Software\Classes\iccmc-uploader"


def _command() -> str:
    """The exact command Windows should run. pythonw so no console window flashes."""
    exe = pathlib.Path(sys.executable)
    pyw = exe.with_name("pythonw.exe")
    if pyw.exists():
        exe = pyw
    script = pathlib.Path(__file__).resolve().parent / "ICCMC uploader.pyw"
    return f'"{exe}" "{script}" "%1"'


def register() -> bool:
    """Claim iccmc-uploader: for this user. Idempotent — safe to call on every start."""
    try:
        import winreg
    except ImportError:
        return False                       # not Windows
    want = _command()
    try:
        # already ours, and pointing at the right place? then leave the registry alone
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY + r"\shell\open\command") as k:
            if winreg.QueryValueEx(k, "")[0] == want:
                return True
    except OSError:
        pass
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, KEY) as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "URL:ICCMC uploader")
            winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, KEY + r"\shell\open\command") as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, want)
        return True
    except OSError:
        return False                       # locked-down machine — not worth failing the app over


def unregister() -> bool:
    """Give the protocol back. Leaves nothing behind."""
    try:
        import winreg
    except ImportError:
        return False
    for sub in (KEY + r"\shell\open\command", KEY + r"\shell\open", KEY + r"\shell", KEY):
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, sub)
        except OSError:
            pass
    return True


def launched_by_link(argv=None) -> bool:
    """Did the website open us, rather than the user double-clicking?"""
    argv = sys.argv[1:] if argv is None else argv
    return any(str(a).lower().startswith("iccmc-uploader:") for a in argv)
